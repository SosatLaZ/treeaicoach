-- TreeAI - compact movable panel with tabs (Maintenant, Quêtes, Groupe, HV, Infos), toolbar,
-- one-line « mini » mode, and a small corner alert box for important (prio 3) items.
-- Taint-safe: plain frames parented to UIParent only, no secure template, never touches Blizzard frames.
local TreeAI = TreeAI
if not TreeAI then return end
local _G = _G
local L = TreeAI.L
local tostring, type, ipairs, pairs, floor, max, min = tostring, type, ipairs, pairs, math.floor, math.max, math.min
-- (PLACEBUG 4.0.1) ancrages sûrs : un point valide et des nombres finis, sinon rien ne bouge — jamais un cadre
-- laissé sans point d'ancrage (ClearAllPoints puis SetPoint raté), jamais un décalage nil → 0 → coin de l'écran
local POINTS = { TOPLEFT = true, TOP = true, TOPRIGHT = true, LEFT = true, CENTER = true, RIGHT = true,
  BOTTOMLEFT = true, BOTTOM = true, BOTTOMRIGHT = true }
local function finite(v) return type(v) == "number" and v == v and v > -100000 and v < 100000 end
local function validAnchor(point, x, y) return POINTS[point] == true and finite(x) and finite(y) end
TreeAI.ValidAnchor = validAnchor

local PRIO_COLORS = {
  [1] = { 0.85, 0.85, 0.85 },
  [2] = { 1.00, 0.82, 0.20 },
  [3] = { 1.00, 0.30, 0.25 },
}
local LINE_H, HEADER_H, TABS_H, PAD = 15, 18, 16, 6
local TAB_ROW_H, TAB_ICON, ROW_GAP = 18, 12, 3
local MIN_W, DEFAULT_W = 300, 320
local MAX_ROWS = 15
-- interface SIMPLE : 4 onglets visibles (Maintenant · Quêtes · Groupe · Plus) ; « Plus » ouvre une 2e rangée
local PRIMARY = { "now", "quests", "group" }
local IS_PRIMARY = { now = true, quests = true, group = true }
local MORE = "__more"
local SHORT = { now = "Maint.", quests = "Quêtes", group = "Groupe", [MORE] = "Plus", hunter = "Chass.",
  gear = "Équip.", prof = "Métiers", talents = "Talents", dungeon = "Donjon", pvp = "JcJ", hv = "HV", info = "Infos",
  binds = "Touches", adv = "Avant.", finder = "Cherch.", stats = "Stats" }
local TAB_ICONS = {
  now = "Interface\\Icons\\Spell_Nature_TimeStop", quests = "Interface\\Icons\\INV_Misc_Note_02",
  group = "Interface\\Icons\\Ability_Hunter_Pet_Wolf", [MORE] = "Interface\\Buttons\\UI-PlusButton-Up",
  hunter = "Interface\\Icons\\Ability_Hunter_BeastCall", hv = "Interface\\Icons\\INV_Misc_Coin_01",
  prof = "Interface\\Icons\\Trade_BlackSmithing", talents = "Interface\\Icons\\Ability_Marksmanship",
  gear = "Interface\\Icons\\INV_Chest_Chain", dungeon = "Interface\\Icons\\INV_Misc_Key_03",
  pvp = "Interface\\Icons\\Ability_DualWield", info = "Interface\\Icons\\INV_Misc_QuestionMark",
  binds = "Interface\\Icons\\INV_Misc_Key_14", adv = "Interface\\Icons\\Ability_Hunter_SniperShot",
  finder = "Interface\\Icons\\INV_Misc_Spyglass_02", stats = "Interface\\Icons\\INV_Misc_PocketWatch_01",
}
TreeAI.PANEL_MIN_WIDTH = MIN_W
local moreOpen = false
local function panelWidth()
  local s = TreeAI.settings and TreeAI.settings.panel
  return max(MIN_W, tonumber(s and s.width) or DEFAULT_W)
end
-- réglages d'apparence (page « Apparence ») : police, interligne, icônes
local function look()
  local s = TreeAI.settings and TreeAI.settings.panel
  local fs = tonumber(s and s.fontSize) or 11
  return fs, tonumber(s and s.lineGap) or ROW_GAP, tonumber(s and s.iconSize) or 13
end
local EMPTY = {
  now = "Rien d'urgent — choisis une quête dans « Quêtes »", quests = "Aucune quête : cherche les « ! » jaunes autour de toi",
  group = "Pas de groupe — invite tes amis (TreeAI partage vos quêtes)",
  hv = "Ouvre l'hôtel des ventes pour chercher des affaires.", info = "Rien à signaler.",
}
local ICONS = {
  compass = "Interface\\Icons\\INV_Misc_Spyglass_02",
  macros = "Interface\\Icons\\INV_Misc_Note_01",
  group = "Interface\\Icons\\Ability_Hunter_Pet_Wolf",
  options = "Interface\\Icons\\INV_Misc_Gear_01",
  locked = "Interface\\Buttons\\LockButton-Locked-Up",
  unlocked = "Interface\\Buttons\\LockButton-Unlocked-Up",
  mini = "Interface\\Buttons\\UI-MinusButton-Up",
  maxi = "Interface\\Buttons\\UI-PlusButton-Up",
  close = "Interface\\Buttons\\UI-StopButton",
  edit = "Interface\\Icons\\INV_Misc_Wrench_01",
  all = "Interface\\Icons\\INV_Misc_Book_09",
  reset = "Interface\\Buttons\\UI-RefreshButton",
  radar = "Interface\\Icons\\INV_Misc_Map_01",
}

-- icône par défaut d'une ligne sans icône : par sujet, sinon par module (repères visuels constants)
local TOPIC_ICONS = {
  ammo = "Interface\\Icons\\INV_Ammo_Arrow_02", bags = "Interface\\Icons\\INV_Misc_Bag_08",
  repair = "Interface\\Icons\\Trade_BlackSmithing", food = "Interface\\Icons\\INV_Misc_Food_15",
  train = "Interface\\Icons\\INV_Misc_Book_09", aspect = "Interface\\Icons\\Ability_Hunter_AspectOfTheMonkey",
  fd = "Interface\\Icons\\Ability_Rogue_FeignDeath", petfood = "Interface\\Icons\\Ability_Hunter_BeastTraining",
  pet = "Interface\\Icons\\Ability_Hunter_BeastCall", hub = "Interface\\Icons\\INV_Misc_Map_01",
  interrupt = "Interface\\Icons\\Ability_Kick", cc = "Interface\\Icons\\Spell_Frost_ChainsOfIce",
}
local MODULE_ICONS = {
  Quests = "Interface\\Icons\\INV_Misc_Note_02", Tracker = "Interface\\Icons\\INV_Misc_Note_02",
  Leveling = "Interface\\Icons\\INV_Misc_Book_09", Compass = "Interface\\Icons\\INV_Misc_Spyglass_02",
  Stats = "Interface\\Icons\\INV_Misc_PocketWatch_01", Group = "Interface\\Icons\\Ability_Hunter_Pet_Wolf",
  Auction = "Interface\\Icons\\INV_Misc_Coin_01", Hunter = "Interface\\Icons\\Ability_Hunter_BeastCall",
  Fight = "Interface\\Icons\\Ability_DualWield", Boost = "Interface\\Icons\\Spell_Holy_BorrowedTime",
  Inventory = "Interface\\Icons\\INV_Misc_Bag_08", Macros = "Interface\\Icons\\INV_Misc_Note_01",
  Classes = "Interface\\Icons\\Spell_Holy_WordFortitude", Pro = "Interface\\Icons\\INV_Misc_Note_02",
}
local function iconOf(e)
  if e.icon then return e.icon end
  local topic = TreeAI.TopicOf and TreeAI:TopicOf(e)
  if topic and TOPIC_ICONS[topic] then return TOPIC_ICONS[topic] end
  local m = e.module or e.source
  return m and MODULE_ICONS[m] or nil
end
TreeAI._IconOf = iconOf

-- ---------------------------------------------------------------- MENU : genre de ligne, couleur, chiffres
-- Genre (danger, quête à rendre, objectif tuer / ramasser / utiliser, trajet / vol / bateau, équipement,
-- familier, équipe, argent, consommables, info) -> une icône et une couleur constantes (Theme.LINE).
local KIND_SET = { danger = true, warn = true, turnin = true, quest = true, kill = true, collect = true, use = true,
  travel = true, flight = true, boat = true, gear = true, pet = true, group = true, money = true, consumable = true,
  info = true }
-- l'icône d'un module (objet précis, nourriture…) dit plus que l'icône du genre : gardée pour ces genres
local KEEP_ICON = { gear = true, consumable = true, money = true, pet = true, info = true, group = true }
local MOD_KIND = { Gear = "gear", Hunter = "pet", Group = "group", Auction = "money", Route = "travel", Speed = "travel",
  Inventory = "consumable" }
local TOPIC_KIND = { ammo = "consumable", food = "consumable", petfood = "pet", pet = "pet", repair = "gear",
  hub = "travel" }
-- verbes : au début de l'action (après « Étape : », « Ensuite : »…)
local VERBS = {
  { "rends ", "turnin" }, { "rendre ", "turnin" }, { "va rendre", "turnin" }, { "remets ", "turnin" },
  { "prends le vol", "flight" }, { "prends un vol", "flight" }, { "vole ", "flight" },
  { "prends le bateau", "boat" }, { "prends le zeppelin", "boat" },
  { "tue ", "kill" }, { "tuer ", "kill" }, { "abats ", "kill" }, { "élimine ", "kill" },
  { "ramasse", "collect" }, { "collecte", "collect" }, { "récupère", "collect" }, { "récolte", "collect" },
  { "rapporte", "collect" }, { "fouille", "collect" }, { "dépèce", "collect" },
  { "utilise ", "use" }, { "sers-toi", "use" },
  { "équipe ", "gear" }, { "répare", "gear" }, { "fais fabriquer", "gear" },
  { "nourris", "pet" }, { "ressuscite ton familier", "pet" }, { "apprivoise", "pet" },
  { "achète", "consumable" }, { "refais le plein", "consumable" }, { "bois ", "consumable" }, { "mange ", "consumable" },
  { "vends ", "money" }, { "mets en vente", "money" },
  { "va ", "travel" }, { "marche", "travel" }, { "rejoins", "travel" }, { "retourne", "travel" }, { "rentre ", "travel" },
  { "cours ", "travel" }, { "arrêt ", "travel" }, { "suis le plan", "travel" }, { "trajet", "travel" },
}
-- mots n'importe où (plus faibles que les verbes)
local NOUNS = {
  { "prête à rendre", "turnin" }, { "à rendre", "turnin" }, { "maître de vol", "flight" }, { "griffon", "flight" },
  { "coursier du vent", "flight" }, { "bateau", "boat" }, { "zeppelin", "boat" }, { "familier", "pet" },
  { "munitions", "consumable" }, { "boisson", "consumable" }, { "nourriture", "consumable" }, { "bandage", "consumable" },
  { "potion", "consumable" }, { "hôtel des ventes", "money" }, { "pierre de foyer", "travel" },
}
local function plainOf(s) return TreeAI.PlainText and TreeAI.PlainText(s) or tostring(s or "") end
local function lineKind(e, tab)
  local txt = e.text
  if e._kindOf == txt and e._kind then return e._kind end
  local k
  if (e.prio or 1) >= 3 then k = "danger"
  elseif e.kind and KIND_SET[e.kind] then k = e.kind
  else
    local low = string.lower(plainOf(txt)):gsub("É", "é"):gsub("À", "à"):gsub("Ê", "ê"):gsub("È", "è")
    -- action = après un court libellé « À faire maintenant : », « Ensuite : », « Étape : »
    local c = low:find(" : ", 1, true)
    local act = (c and c <= 24 and not low:sub(1, c):find("«", 1, true)) and low:sub(c + 3) or low
    for _, v in ipairs(VERBS) do
      if act:sub(1, #v[1]) == v[1] then k = v[2] break end
    end
    if not k then
      for _, v in ipairs(NOUNS) do if low:find(v[1], 1, true) then k = v[2] break end end
    end
    if not k then
      local topic = TreeAI.TopicOf and TreeAI:TopicOf(e)
      k = (topic and TOPIC_KIND[topic]) or MOD_KIND[e.module or e.source or ""]
    end
    if not k and e.questID then k = "quest" end
    if not k and tab == "group" then k = "group" end
    if not k and tab == "hv" then k = "money" end
    k = k or "info"
  end
  e._kind, e._kindOf = k, txt
  return k
end
TreeAI._LineKind = lineKind

-- chiffres compacts (distance, durée, XP/h…) déplacés dans une colonne de droite alignée
local UNITS = { [""] = true, m = true, km = true, yd = true, s = true, min = true, h = true, ["%"] = true,
  po = true, pa = true, pc = true, ["xp/h"] = true, ["xp/min"] = true, xp = true }
local MID = " · "
local function numSeg(seg)
  local p = plainOf(seg):gsub("^%s+", ""):gsub("%s+$", "")
  if p == "" or #p > 18 then return nil end
  local body = p:gsub("^~%s*", ""):gsub("^≈%s*", "")
  if body:match("^%d+ h %d%d$") or body:match("^%d+ min %d%d$") then return p end
  local n, unit = body:match("^(%d[%d%s%.,:]*)%s*(%S*)$")
  if not n or not UNITS[unit:lower()] then return nil end
  return p
end
local function closeColor(s)
  local _, o = s:gsub("|c%x%x%x%x%x%x%x%x", "")
  local _, c = s:gsub("|r", "")
  if o > c then s = s .. "|r" end
  return (s:gsub("%s+$", ""))
end
local function splitRight(text)
  text = tostring(text or "")
  local a, init = nil, 1
  while true do
    local f = text:find(MID, init, true)
    if not f then break end
    a, init = f, f + 1
  end
  if a and a > 1 then
    local r = numSeg(text:sub(a + #MID))
    if r then return closeColor(text:sub(1, a - 1)), r end
  end
  local head, inner = text:match("^(.-)%s*%(([^()]+)%)%s*$")
  if head and plainOf(head):find("%S") then
    local r = numSeg(inner)
    if r then return closeColor(head), r end
  end
  return text, nil
end
TreeAI._SplitRight = splitRight

-- noms des membres du groupe aux couleurs de leur classe (cache 2 s, jamais de valeur « secrète »)
local partyHex, partyAt = {}, -10
local function isSecret(v) local f = rawget(_G, "issecretvalue") return type(f) == "function" and f(v) and true or false end
local function partyColors()
  local t = (_G.GetTime and _G.GetTime()) or 0
  if t - partyAt < 2 then return partyHex end
  partyAt = t
  for k in pairs(partyHex) do partyHex[k] = nil end
  local Th, un, uc = TreeAI.Theme, _G.UnitName, _G.UnitClass
  if not (Th and Th.ClassColor and un and uc) then return partyHex end
  for i = 1, 4 do
    local u = "party" .. i
    local ok, n = pcall(un, u)
    if ok and type(n) == "string" and not isSecret(n) and n ~= "" then
      local okc, _, cls = pcall(uc, u)
      if okc and type(cls) == "string" and not isSecret(cls) then
        local r, g, b = Th:ClassColor(cls)
        partyHex[n] = ("ff%02x%02x%02x"):format(floor(r * 255 + 0.5), floor(g * 255 + 0.5), floor(b * 255 + 0.5))
      end
    end
  end
  return partyHex
end
local function colorNames(text)
  for n, hex in pairs(partyColors()) do
    local a = text:find(n, 1, true)
    if a and not (a > 10 and text:sub(a - 10, a - 1):match("|c%x%x%x%x%x%x%x%x$")) then
      text = text:sub(1, a - 1) .. "|c" .. hex .. n .. "|r" .. text:sub(a + #n)
    end
  end
  return text
end
TreeAI._ColorNames = colorNames

-- ce que fait le clic (1re ligne de l'infobulle) : texte du module, sa ligne « Clic … », sinon selon le genre
local CLICK_BY_KIND = {
  quest = "Clic : la boussole pointe vers cette quête", turnin = "Clic : la boussole pointe vers le PNJ de remise",
  kill = "Clic : la boussole pointe vers les monstres", collect = "Clic : la boussole pointe vers les objets",
  use = "Clic : la boussole pointe vers l'endroit", travel = "Clic : guider jusque-là",
  flight = "Clic : guider jusqu'au maître de vol", boat = "Clic : guider jusqu'au quai", gear = "Clic : voir / équiper",
  pet = "Clic : s'occuper du familier", group = "Clic : prévenir le groupe", money = "Clic : ouvrir / acheter",
  consumable = "Clic : utiliser / préparer", danger = "Clic : réagir", warn = "Clic : détails", info = "Clic : faire l'action",
}
local function clickLineOf(e, rest)
  if e.clickHint then return tostring(e.clickHint) end
  for i, l in ipairs(rest) do
    local t = type(l) == "table" and l[1]
    local p = t and plainOf(t):gsub("^%s+", "")
    if p and p:sub(1, 5) == "Clic " and p:sub(1, 10) ~= "Clic droit" then
      table.remove(rest, i)
      return p
    end
  end
  return CLICK_BY_KIND[e._kind or "info"] or CLICK_BY_KIND.info
end

local panel, rows, tabButtons, tools = nil, {}, {}, {}
local scroll = {}          -- tabId -> first visible index
local current = {}         -- entries of the visible tab
local alert

local function acc() return TreeAI.settings and TreeAI.settings.panel end
local function char() return TreeAI.PanelChar and TreeAI:PanelChar() or acc() end
local function activeTab()
  local c = char()
  local id = c and c.tab or "now"
  if not TreeAI.tabs[id] then id = "now" end
  return id
end
local function isMini() local c = char(); return c and c.mini and true or false end

local function savePosition()
  local c = char()
  if not (panel and c) then return end
  -- (PLACEBUG) relu depuis le rectangle réel et reposé avec un ancrage explicite sur UIParent (jamais l'ancrage que
  -- le client met après StopMovingOrSizing, jamais « nil → 0 »)
  if TreeAI._PlayerMoved then TreeAI._PlayerMoved(panel, "panel") end
  local point, _, _, x, y = panel:GetPoint(1)
  if validAnchor(point, x, y) then c.point, c.x, c.y = point, x, y end
end

local function applyPosition()
  local s, c = acc(), char()
  if not (panel and s and c) then return end
  -- (PLACEBUG) place incomplète (x / y absents, point inconnu) : la place par défaut, jamais « 0, 0 » (un coin)
  if not validAnchor(c.point, c.x, c.y) then c.point, c.x, c.y = "CENTER", 300, 120 end
  panel:ClearAllPoints()
  panel:SetPoint(c.point, _G.UIParent, c.point, c.x, c.y)
  panel:SetScale(s.scale or 1)
  panel:SetAlpha(s.alpha or 0.9)
  panel:SetWidth(panelWidth())
end

local function startMove()
  local s = acc()
  if not panel or (s and s.locked) or TreeAI:InCombat() then return end
  panel:StartMoving()
end
local function stopMove()
  if not panel then return end
  panel:StopMovingOrSizing()
  savePosition()
  local c = char()
  if c then c.manual = true end   -- déplacé à la main : le placement auto ne le bouge plus
  local st = TreeAI.db and TreeAI:CharKey() ~= "?" and TreeAI:CharDB().layout
  if type(st) == "table" and type(st.manual) == "table" then st.manual.panel = true end
end
local function draggable(f)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", startMove)
  f:SetScript("OnDragStop", stopMove)
end

local function showTooltip(owner, title, lines)
  local tt = _G.GameTooltip
  if not tt then return end
  -- (4.0 QA) « → », « ✓ »… absents des polices du jeu : la même table que les lignes (SafeText)
  local function sf(x) local ok, r = pcall(TreeAI.SafeText, x) return (ok and r) or x end   -- (valeur secrète : telle quelle)
  tt:SetOwner(owner, "ANCHOR_LEFT")
  tt:AddLine(sf(title or ""), 1, 1, 1, true)
  for _, l in ipairs(lines or {}) do
    if l == " " then tt:AddLine(" ") else tt:AddLine(sf(l[1] or ""), l[2] or 0.8, l[3] or 0.8, l[4] or 0.8, true) end
  end
  tt:Show()
end
local function hideTooltip() if _G.GameTooltip then _G.GameTooltip:Hide() end end

local function isSuggestion(e) return e and e.source == nil and e.time ~= nil end

local function entryTooltip(owner, e)
  local extra = {}
  local t = e.tooltip
  if type(t) == "string" then extra[#extra + 1] = { t, 0.9, 0.9, 0.9 }
  elseif type(t) == "table" then
    for _, l in ipairs(t) do extra[#extra + 1] = { tostring(l), 0.9, 0.9, 0.9 } end
  end
  -- MENU : 1re ligne = ce que fait le clic (bleu), puis le texte complet de la ligne, puis le détail
  local clickable = e.onClick ~= nil
  local first = clickable and clickLineOf(e, extra) or nil
  if first then table.insert(extra, 1, { e.text, 1, 1, 1 }) end
  if e._guide then extra[#extra + 1] = { e._guide, 0.55, 0.8, 1 } end
  if e._note then extra[#extra + 1] = { e._note, 1, 0.6, 0.15 } end
  if e.macro then
    extra[#extra + 1] = " "
    extra[#extra + 1] = { L["Macro proposée"] .. " :", 0.6, 0.8, 1 }
    extra[#extra + 1] = { e.macro, 0.9, 0.9, 0.9 }
  end
  if type(e._also) == "table" then
    local names = {}
    for m in pairs(e._also) do
      local mod = TreeAI.modules and TreeAI.modules[m]
      names[#names + 1] = L[(mod and mod.title) or m]
    end
    table.sort(names)
    if #names > 0 then extra[#extra + 1] = { L["Aussi signalé par"] .. " : " .. table.concat(names, ", "), 0.6, 0.6, 0.6 } end
  end
  if e.onRightClick then extra[#extra + 1] = { L["Clic droit : options"], 0.5, 0.5, 0.5 }
  elseif isSuggestion(e) then extra[#extra + 1] = { L["Clic droit: masquer"], 0.5, 0.5, 0.5 } end
  if first then
    local tt = _G.GameTooltip
    if tt then
      tt:SetOwner(owner, "ANCHOR_LEFT")
      tt:AddLine(first, 0.4, 0.8, 1, true)
      for _, l in ipairs(extra) do
        if l == " " then tt:AddLine(" ") else tt:AddLine(l[1], l[2] or 0.8, l[3] or 0.8, l[4] or 0.8, true) end
      end
      tt:Show()
    end
    TreeAI._lastTooltipFirst = first
  else
    showTooltip(owner, e.text, extra)
    TreeAI._lastTooltipFirst = e.text
  end
end
-- curseur « main » sur ce qui se clique (gardé : SetCursor peut manquer)
local function pointer(on)
  local f = on and rawget(_G, "SetCursor") or rawget(_G, "ResetCursor")
  if type(f) == "function" then
    if on then pcall(f, "Interface\\CURSOR\\Point") else pcall(f) end
  end
end

local function runEntry(e, button)
  if not e then return end
  if button == "RightButton" then
    if e.onRightClick then TreeAI:UserAction(e.onRightClick, e)   -- (ZONEPLAN) menu de la ligne (ex. « Ignorer cette quête »)
    elseif isSuggestion(e) then if TreeAI.DismissSuggestion then TreeAI:DismissSuggestion(e.id) else TreeAI:ClearSuggestion(e.id) end end
  elseif e.onClick then
    TreeAI:UserAction(e.onClick, e)
  end
end

local function makeRow(i)
  local b = _G.CreateFrame("Button", nil, panel)
  b:SetHeight(LINE_H)
  b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  draggable(b)
  b.icon = b:CreateTexture(nil, "ARTWORK")
  b.icon:SetSize(13, 13)
  b.icon:SetPoint("TOPLEFT", b, "TOPLEFT", 0, -1)
  b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  b.text:SetPoint("TOPLEFT", b, "TOPLEFT", 16, 0)
  b.text:SetPoint("TOPRIGHT", b, "TOPRIGHT", 0, 0)
  b.text:SetJustifyH("LEFT")
  if b.text.SetJustifyV then b.text:SetJustifyV("TOP") end
  -- 2 lignes au lieu d'une ligne coupée « … » (texte complet dans l'infobulle)
  if b.text.SetWordWrap then b.text:SetWordWrap(true) end
  if b.text.SetNonSpaceWrap then b.text:SetNonSpaceWrap(false) end
  if b.text.SetMaxLines then b.text:SetMaxLines(4) end
  -- MENU : colonne de droite (distance, durée, XP/h…) alignée à droite, largeur commune à l'onglet
  b.right = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  b.right:SetJustifyH("RIGHT")
  if b.right.SetJustifyV then b.right:SetJustifyV("TOP") end
  if b.right.SetWordWrap then b.right:SetWordWrap(false) end
  b.right:SetTextColor(0.75, 0.85, 1)
  -- chevron « › » : la ligne se clique
  b.chev = b:CreateTexture(nil, "ARTWORK")
  b.chev:SetSize(8, 8)
  b.chev:SetTexture("Interface\\ChatFrame\\ChatFrameExpandArrow")
  b.chev:SetPoint("TOPRIGHT", b, "TOPRIGHT", 0, -3)
  if b.chev.SetVertexColor then b.chev:SetVertexColor(1, 1, 1, 0.45) end
  b.hl = b:CreateTexture(nil, "HIGHLIGHT")
  b.hl:SetAllPoints(b)
  b.hl:SetTexture("Interface\\Buttons\\WHITE8X8")
  if b.hl.SetVertexColor then b.hl:SetVertexColor(1, 1, 1, 0.08) end
  b:SetScript("OnClick", function(self, button) runEntry(self.entry, button) end)
  b:SetScript("OnEnter", function(self)
    if self.entry then
      entryTooltip(self, self.entry)
      if self.entry.onClick then pointer(true) end
    end
  end)
  b:SetScript("OnLeave", function() hideTooltip(); pointer(false) end)
  b.index = i
  return b
end

local function toolButton(key, tip, fn)
  local b = _G.CreateFrame("Button", nil, panel)
  b:SetSize(14, 14)
  b.tex = b:CreateTexture(nil, "ARTWORK")
  b.tex:SetAllPoints(b)
  b.tex:SetTexture(ICONS[key])
  b:SetScript("OnClick", function(self, button) TreeAI.safecall(fn, self, button) end)
  b:SetScript("OnEnter", function(self) showTooltip(self, type(tip) == "function" and tip() or tip) end)
  b:SetScript("OnLeave", hideTooltip)
  tools[#tools + 1] = b
  tools[key] = b
  return b
end

local function toggleCompass()
  local C = TreeAI.Compass or (TreeAI.GetModule and TreeAI:GetModule("Compass"))
  if type(C) == "table" then
    for _, fn in ipairs({ "Toggle", "ToggleShown", "ToggleFrame" }) do
      if type(C[fn]) == "function" then TreeAI.safecall(C[fn], C); return end
    end
  end
  TreeAI:HandleSlash("boussole")
end

--- (4.0 QA) un clic refusé (combat…) : le message rouge du jeu au centre de l'écran, jamais une ligne dans le chat
function TreeAI:CombatRefused(msg)
  msg = msg or L["Impossible en combat."]
  local ef = _G.UIErrorsFrame
  if ef and ef.AddMessage and pcall(ef.AddMessage, ef, msg, 1, 0.3, 0.2) then return end
  self:Print(msg)
end

--- (4.0) la réponse à un clic qui n'a rien d'autre à montrer : le pied de la fenêtre TreeAI quand elle est ouverte,
--- sinon le message doré du jeu au centre de l'écran ; jamais une ligne dans le chat
function TreeAI:ClickNote(msg)
  msg = tostring(msg or "")
  local Wn = self.Window
  local win = Wn and Wn._active and Wn.GetWindow and Wn.GetWindow()
  if win and win.IsShown and win:IsShown() and Wn.Flash then Wn.Flash(msg) return end
  local ef = _G.UIErrorsFrame
  if ef and ef.AddMessage and pcall(ef.AddMessage, ef, self.SafeText and self.SafeText(msg) or msg, 1, 0.82, 0) then return end
  self:Print(msg)
end

local function toggleMacros()
  if TreeAI:InCombat() then TreeAI:CombatRefused(); return end
  local M = TreeAI.GetModule and TreeAI:GetModule("Macros")
  if M and type(M.TogglePanel) == "function" then TreeAI.safecall(M.TogglePanel, M) end
end

local function tabTitle(id)
  if id == MORE then return L["Plus"] end
  local t = TreeAI.tabs[id]
  return L[(t and t.title) or id]
end

local function newTabButton(id, icon)
  local b = _G.CreateFrame("Button", nil, panel)
  b:SetHeight(TAB_ROW_H)
  draggable(b)
  b.icon = b:CreateTexture(nil, "ARTWORK")
  b.icon:SetSize(TAB_ICON, TAB_ICON)
  b.icon:SetPoint("LEFT", b, "LEFT", 2, 0)
  b.icon:SetTexture(icon or TAB_ICONS[id] or TAB_ICONS.info)
  b.text = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  b.text:SetPoint("LEFT", b.icon, "RIGHT", 2, 0)
  b.text:SetJustifyH("LEFT")
  if b.text.SetWordWrap then b.text:SetWordWrap(false) end
  b.line = b:CreateTexture(nil, "ARTWORK")
  b.line:SetHeight(2)
  b.line:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", 2, 0)
  b.line:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -2, 0)
  b.line:SetTexture("Interface\\Buttons\\WHITE8X8")
  if b.line.SetVertexColor then b.line:SetVertexColor(0.2, 0.8, 0.4, 0.9) end
  -- MENU : pastille de compte (quêtes, urgences, membres…) à droite de l'onglet
  b.badge = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  b.badge:SetPoint("RIGHT", b, "RIGHT", -2, 0)
  b.badge:SetJustifyH("RIGHT")
  if b.badge.SetWordWrap then b.badge:SetWordWrap(false) end
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetAllPoints(b)
  b.bg:SetTexture("Interface\\Buttons\\WHITE8X8")
  if b.bg.SetVertexColor then b.bg:SetVertexColor(1, 1, 1, 0.05) end
  b:SetScript("OnLeave", hideTooltip)
  return b
end

local function tabButton(id)
  local b = tabButtons[id]
  if b then return b end
  b = newTabButton(id)
  b.id = id
  if id == MORE then
    b:SetScript("OnClick", function() TreeAI:ToggleMoreMenu() end)
    b:SetScript("OnEnter", function(self)
      showTooltip(self, L["Plus"], { { L["HV, Métiers, Talents, Équipement, Donjon, JcJ, Stats, Infos…"], 0.8, 0.8, 0.8 } })
    end)
  else
    b:SetScript("OnClick", function(self) TreeAI:SelectTab(self.id) end)
    b:SetScript("OnEnter", function(self)
      showTooltip(self, tabTitle(self.id), { { L["Molette : faire défiler"], 0.6, 0.6, 0.6 } })
    end)
  end
  tabButtons[id] = b
  return b
end

-- actions du sous-menu « Plus » (boutons, pas des onglets), rangées en groupes : Outils puis Réglages
local actionButtons = {}
local MORE_GROUPS = {
  { id = "jeu", title = "Jeu", icon = "Interface\\Icons\\INV_Misc_Map_01" },
  { id = "outils", title = "Outils", icon = "Interface\\Icons\\INV_Misc_Wrench_01" },
  { id = "reglages", title = "Réglages", icon = "Interface\\Icons\\INV_Misc_Gear_01" },
}
local MORE_ACTIONS = {
  { key = "act:macros", group = "outils", title = "Macros", icon = ICONS.macros, fn = function() toggleMacros() end,
    tip = "Clic : ouvrir les macros (en prendre une)" },
  { key = "act:all", group = "outils", title = "Tout (aide)", icon = ICONS.all, fn = function() if TreeAI.ShowHelp then TreeAI:ShowHelp() end end,
    tip = "Clic : toutes les actions des modules et les commandes" },
  { key = "act:options", group = "reglages", title = "Options", icon = ICONS.options,
    fn = function() if TreeAI.OpenOptions then TreeAI:OpenOptions() end end, tip = "Clic : réglages (taille, transparence, modules…)" },
  { key = "act:edit", group = "reglages", title = "Déplacer les cadres", icon = ICONS.edit,
    fn = function() TreeAI:SetEditMode(not TreeAI:IsEditMode()) end, tip = "Clic : mode édition (glisser, molette = taille)" },
  { key = "act:reset", group = "reglages", title = "Réinitialiser l'interface", icon = ICONS.reset, wide = true,
    fn = function() TreeAI:ResetInterface() end,
    tip = "Clic : remet tous les cadres TreeAI à leur place automatique, taille et onglets par défaut" },
}
local function actionButton(a)
  local b = actionButtons[a.key]
  if b then return b end
  b = newTabButton(a.key, a.icon)
  b.action = a.key
  b:SetScript("OnClick", function() TreeAI.safecall(a.fn) end)
  b:SetScript("OnEnter", function(self) showTooltip(self, L[a.title], a.tip and { { L[a.tip], 0.8, 0.8, 0.8 } } or nil) end)
  actionButtons[a.key] = b
  return b
end

local function buildTabs()
  for _, t in ipairs(TreeAI:GetTabs()) do tabButton(t.id) end
  for _, id in ipairs(PRIMARY) do tabButton(id) end
  tabButton(MORE)
end

-- texte qui tient dans maxW : libellé complet, sinon court, sinon coupé + « … » (jamais de chevauchement)
local function fitLabel(fs, full, short, maxW)
  fs:SetText(full)
  if (fs:GetStringWidth() or 0) <= maxW then return full end
  if short and short ~= full then
    fs:SetText(short)
    if (fs:GetStringWidth() or 0) <= maxW then return short end
  end
  local s = short or full
  while #s > 0 do
    s = s:gsub("[%z\1-\127\192-\253][\128-\191]*$", "")
    fs:SetText(s .. "…")
    if (fs:GetStringWidth() or 0) <= maxW then return s .. "…" end
  end
  fs:SetText("")
  return ""
end
TreeAI._FitLabel = fitLabel

local function isMoreTab(id) return id ~= nil and not IS_PRIMARY[id] end

-- onglets secondaires (groupe « Jeu », dans l'ordre des onglets) puis actions (« Outils », « Réglages »)
local function moreEntries()
  local out = {}
  for _, t in ipairs(TreeAI:GetTabs()) do
    if not IS_PRIMARY[t.id] then out[#out + 1] = { id = t.id, order = t.order, group = "jeu" } end
  end
  local tal = TreeAI.tabs.talents
  if tal and #TreeAI:GetTabLines("talents") > 0 then out[#out + 1] = { id = "talents", order = tal.order, group = "jeu" } end
  table.sort(out, function(a, b) if a.order ~= b.order then return a.order < b.order end return a.id < b.id end)
  for _, a in ipairs(MORE_ACTIONS or {}) do
    if not a.when or a.when() then out[#out + 1] = { id = a.key, action = a, group = a.group } end
  end
  return out
end

-- rangée 1 = 4 cases égales (Maintenant · Quêtes · Groupe · Plus) ; rangées suivantes (« Plus » ouvert ou
-- onglet secondaire actif) = boutons à leur largeur mesurée, renvoyés à la ligne. Renvoie la hauteur prise.
-- tabRects garde la géométrie (tests : aucun chevauchement, texte ≤ case).
local tabRects = {}
local function shortOf(id) return SHORT[id] and L[SHORT[id]] or nil end
-- pastille d'un onglet : texte (compte) + couleur, ou nil
local function urgentCount(list)
  local n = 0
  for _, e in ipairs(list) do if (e.prio or 1) >= 3 and not e.control then n = n + 1 end end
  return n
end
local badgeMemo = {}   -- (3.9.9) id -> { at, a, b, c, d } : pastilles « Plus » / onglets secondaires relues au plus toutes les 2 s
local badgeCompute
local function badgeOf(id)
  if IS_PRIMARY[id] then return badgeCompute(id) end   -- onglets toujours visibles : lignes déjà calculées par le rendu
  local t = (_G.GetTime and _G.GetTime()) or 0
  local m = badgeMemo[id]
  if m and t - m.at < 2 and t >= m.at then return m[1], m[2], m[3], m[4] end
  local a, b, c, d = badgeCompute(id)
  m = m or {}
  m.at, m[1], m[2], m[3], m[4] = t, a, b, c, d
  badgeMemo[id] = m
  return a, b, c, d
end
function badgeCompute(id)
  if id == MORE then
    local n = 0
    for _, t in ipairs(TreeAI:GetTabs()) do
      if not IS_PRIMARY[t.id] then n = n + urgentCount(TreeAI:GetTabLines(t.id)) end
    end
    if n > 0 then return tostring(n), 1, 0.35, 0.3 end
    return nil
  end
  local list = TreeAI:GetTabLines(id)
  local u = urgentCount(list)
  if u > 0 then return tostring(u), 1, 0.35, 0.3 end
  if id == "now" then return nil end
  local n, ready = 0, 0
  if id == "quests" then
    for _, e in ipairs(list) do
      if e.questID then
        n = n + 1
        if lineKind(e, id) == "turnin" then ready = ready + 1 end
      end
    end
    if n > 0 then
      if ready > 0 then return tostring(n), 0.4, 1, 0.4 end
      return tostring(n), 0.8, 0.8, 0.8
    end
    return nil
  end
  for _, e in ipairs(list) do if not e.control then n = n + 1 end end
  if n > 0 then return tostring(n), 0.8, 0.8, 0.8 end
  return nil
end
TreeAI._TabBadge = badgeOf
local function layoutTabs(width)
  for i = #tabRects, 1, -1 do tabRects[i] = nil end
  for _, b in pairs(tabButtons) do b:Hide() end
  local inner = width - 2 * PAD
  local slot = floor(inner / 4)
  local function place(b, x, row, w, full, short)
    b:ClearAllPoints()
    b:SetPoint("TOPLEFT", panel, "TOPLEFT", x, -HEADER_H - row * (TAB_ROW_H + 2))
    b:SetWidth(w)
    b:SetHeight(TAB_ROW_H)
    b:Show()
    local bt, br, bg, bb = badgeOf(b.id)
    local bw = 0
    if bt and b.badge then
      b.badge:SetText(bt)
      b.badge:SetTextColor(br, bg, bb)
      b.badge:Show()
      bw = floor((b.badge:GetStringWidth() or 0) + 3)
      if bw > w / 3 then b.badge:Hide(); bw, bt = 0, nil end
    elseif b.badge then b.badge:SetText(""); b.badge:Hide() end
    local maxW = w - TAB_ICON - 6 - bw
    local label = fitLabel(b.text, full, short, maxW)
    tabRects[#tabRects + 1] = { id = b.id or b.action, x = x, w = w, row = row, text = label,
      textW = (b.text:GetStringWidth() or 0) + bw, textMax = w - TAB_ICON - 6, badge = bt }
  end
  -- une seule rangée : Maintenant · Quêtes · Groupe · « Plus » (= l'onglet secondaire actif s'il y en a un)
  local act = activeTab()
  for i, id in ipairs({ PRIMARY[1], PRIMARY[2], PRIMARY[3], MORE }) do
    local b = tabButton(id)
    local w = slot - 2
    local full, short = tabTitle(id), shortOf(id)
    if id == MORE then
      if isMoreTab(act) then
        full, short = tabTitle(act), shortOf(act)
        b.icon:SetTexture(TAB_ICONS[act] or TAB_ICONS.info)
      else
        b.icon:SetTexture(TAB_ICONS[MORE])
      end
    end
    place(b, PAD + (i - 1) * slot, 0, w, full, short)
  end
  return TAB_ROW_H + 2
end

-- menu déroulant « Plus » : une liste propre sous l'onglet (onglets secondaires, séparateur, actions) ;
-- se ferme au clic (dedans ou ailleurs) et à Échap. Cadre à nous, enfant d'UIParent.
local menu
local menuEntries = {}
local MENU_ROW, MENU_MIN_W = 20, 180
local function closeMenu()
  moreOpen = false
  if menu and menu:IsShown() then menu:Hide() end
end
local function buildMenu()
  if menu or not _G.CreateFrame then return menu end
  local template = _G.BackdropTemplateMixin and "BackdropTemplate" or nil
  menu = _G.CreateFrame("Frame", "TreeAIMoreMenu", _G.UIParent, template)
  menu:SetFrameStrata("DIALOG")
  menu:SetClampedToScreen(true)
  menu:EnableMouse(true)
  if menu.SetBackdrop then
    menu:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
      edgeSize = 10, insets = { left = 2, right = 2, top = 2, bottom = 2 } })
    menu:SetBackdropColor(0.05, 0.06, 0.08, 0.96)
    menu:SetBackdropBorderColor(0.78, 0.62, 0.28, 0.6)
  end
  menu.rows, menu.seps = {}, {}
  menu:SetScript("OnHide", function() moreOpen = false; if panel then TreeAI:RequestRefresh() end end)
  -- clic ailleurs = fermer (événement du client moderne, gardé)
  if menu.RegisterEvent and pcall(menu.RegisterEvent, menu, "GLOBAL_MOUSE_DOWN") then
    menu:SetScript("OnEvent", function(self)
      if not self:IsShown() then return end
      local over = (self.IsMouseOver and self:IsMouseOver()) or false
      local mb = tabButtons[MORE]
      if not over and not (mb and mb.IsMouseOver and mb:IsMouseOver()) then closeMenu() end
    end)
  end
  local list = rawget(_G, "UISpecialFrames")
  if type(list) == "table" then list[#list + 1] = "TreeAIMoreMenu" end   -- Échap ferme (notre cadre seulement)
  menu:Hide()
  return menu
end
local function menuRow(i)
  local b = menu.rows[i]
  if b then return b end
  b = _G.CreateFrame("Button", nil, menu)
  b:SetHeight(MENU_ROW)
  b:RegisterForClicks("LeftButtonUp")
  b.icon = b:CreateTexture(nil, "ARTWORK")
  b.icon:SetSize(14, 14)
  b.icon:SetPoint("LEFT", b, "LEFT", 6, 0)
  b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  b.text:SetPoint("LEFT", b.icon, "RIGHT", 6, 0)
  b.text:SetPoint("RIGHT", b, "RIGHT", -30, 0)
  b.text:SetJustifyH("LEFT")
  if b.text.SetWordWrap then b.text:SetWordWrap(false) end
  b.count = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  b.count:SetPoint("RIGHT", b, "RIGHT", -6, 0)
  b.count:SetJustifyH("RIGHT")
  b.hl = b:CreateTexture(nil, "HIGHLIGHT")
  b.hl:SetAllPoints(b)
  b.hl:SetTexture("Interface\\Buttons\\WHITE8X8")
  if b.hl.SetVertexColor then b.hl:SetVertexColor(1, 1, 1, 0.10) end
  b.sel = b:CreateTexture(nil, "BACKGROUND")
  b.sel:SetAllPoints(b)
  b.sel:SetTexture("Interface\\Buttons\\WHITE8X8")
  if b.sel.SetVertexColor then b.sel:SetVertexColor(0.78, 0.62, 0.28, 0.25) end
  b:SetScript("OnClick", function(self)
    local e = self.e
    closeMenu()
    if not e then return end
    if e.action then TreeAI.safecall(e.action.fn) else TreeAI:SelectTab(e.id) end
  end)
  b:SetScript("OnEnter", function(self)
    local e = self.e
    if not e then return end
    if e.action then showTooltip(self, L[e.action.tip or e.action.title], { { L[e.action.title], 0.8, 0.8, 0.8 } })
    else showTooltip(self, L["Clic : ouvrir l'onglet"] .. " « " .. tabTitle(e.id) .. " »", nil) end
    pointer(true)
  end)
  b:SetScript("OnLeave", function() hideTooltip(); pointer(false) end)
  menu.rows[i] = b
  return b
end
local MENU_HEAD = 16
local function menuHead(i)
  menu.heads = menu.heads or {}
  local h = menu.heads[i]
  if h then return h end
  h = menu:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  h:SetJustifyH("LEFT")
  if h.SetWordWrap then h:SetWordWrap(false) end
  h.icon = menu:CreateTexture(nil, "ARTWORK")
  h.icon:SetSize(12, 12)
  menu.heads[i] = h
  return h
end
local function menuSep(i, y)
  local t = menu.seps[i]
  if not t then
    t = menu:CreateTexture(nil, "ARTWORK")
    t:SetTexture("Interface\\Buttons\\WHITE8X8")
    if t.SetVertexColor then t:SetVertexColor(0.78, 0.62, 0.28, 0.35) end
    t:SetHeight(1)
    menu.seps[i] = t
  end
  t:ClearAllPoints()
  t:SetPoint("TOPLEFT", menu, "TOPLEFT", 8, y)
  t:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -8, y)
  t:Show()
end
local function fillMenu()
  if not buildMenu() then return end
  for i = #menuEntries, 1, -1 do menuEntries[i] = nil end
  for _, r in ipairs(menu.rows) do r:Hide(); r.e = nil end
  for _, t in ipairs(menu.seps) do t:Hide() end
  for _, h in ipairs(menu.heads or {}) do h:Hide(); h.icon:Hide() end
  local act = activeTab()
  local entries = moreEntries()
  -- largeur : le libellé le plus long (mesuré, pastille comprise), au moins MENU_MIN_W
  local probe = menuRow(1)
  local w = MENU_MIN_W
  for _, e in ipairs(entries) do
    probe.text:SetText(e.action and L[e.action.title] or tabTitle(e.id))
    w = max(w, floor((probe.text:GetStringWidth() or 0) + 14 + 6 + 6 + 12 + 6 + 24))
  end
  w = min(w, 320)
  local y, n, seps, heads, lastGroup = -4, 0, 0, 0, nil
  for _, e in ipairs(entries) do
    if e.group ~= lastGroup then
      if lastGroup ~= nil then   -- séparateur entre deux groupes
        seps = seps + 1
        menuSep(seps, y - 3)
        menuEntries[#menuEntries + 1] = { kind = "sep", y = y - 3, h = 1 }
        y = y - 7
      end
      lastGroup = e.group
      local g
      for _, gg in ipairs(MORE_GROUPS) do if gg.id == e.group then g = gg end end
      if g then
        heads = heads + 1
        local h = menuHead(heads)
        h.icon:ClearAllPoints()
        h.icon:SetPoint("TOPLEFT", menu, "TOPLEFT", 8, y - 2)
        h.icon:SetTexture(g.icon)
        h.icon:Show()
        h:ClearAllPoints()
        h:SetPoint("TOPLEFT", menu, "TOPLEFT", 24, y - 2)
        h:SetWidth(w - 32)
        h:SetText(L[g.title])
        h:SetTextColor(0.78, 0.62, 0.28)
        h:Show()
        menuEntries[#menuEntries + 1] = { kind = "header", group = g.id, y = y, h = MENU_HEAD, text = L[g.title],
          textW = h:GetStringWidth() or 0, textMax = w - 32 }
        y = y - MENU_HEAD
      end
    end
    n = n + 1
    local b = menuRow(n)
    b.e = e
    b:ClearAllPoints()
    b:SetPoint("TOPLEFT", menu, "TOPLEFT", 3, y)
    b:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -3, y)
    b:SetWidth(w - 6)
    local label = e.action and L[e.action.title] or tabTitle(e.id)
    b.icon:SetTexture(e.action and e.action.icon or TAB_ICONS[e.id] or TAB_ICONS.info)
    local count = nil
    if e.action then b.text:SetTextColor(0.6, 0.85, 1); b.sel:Hide()
    else
      local list = TreeAI:GetTabLines(e.id)
      local urgent = urgentCount(list)
      local nl = 0
      for _, l in ipairs(list) do if not l.control then nl = nl + 1 end end
      if e.id == act then b.text:SetTextColor(1, 1, 1); b.sel:Show()
      elseif urgent > 0 then b.text:SetTextColor(1, 0.35, 0.3); b.sel:Hide()
      elseif nl == 0 then b.text:SetTextColor(0.55, 0.55, 0.55); b.sel:Hide()
      else b.text:SetTextColor(1, 0.82, 0); b.sel:Hide() end
      if urgent > 0 then count = "|cffff5a4d" .. urgent .. "|r" elseif nl > 0 then count = "|cffaaaaaa" .. nl .. "|r" end
    end
    b.text:SetText(label)
    local textW = b.text:GetStringWidth() or 0
    if b.count then
      if count then b.count:SetText(count); b.count:Show() else b.count:SetText(""); b.count:Hide() end
    end
    b:Show()
    menuEntries[#menuEntries + 1] = { kind = e.action and "action" or "tab", id = e.id, group = e.group, y = y, h = MENU_ROW,
      w = w - 6, text = label, textW = textW, textMax = w - 6 - 14 - 6 - 6 - 6 - 24, count = count }
    y = y - MENU_ROW
  end
  menu:SetSize(w, -y + 4)
  local mb = tabButtons[MORE]
  menu:ClearAllPoints()
  if mb then menu:SetPoint("TOPRIGHT", mb, "BOTTOMRIGHT", 0, -2)
  else menu:SetPoint("TOP", _G.UIParent, "TOP", 0, -200) end
  menu:SetScale((acc() and acc().scale) or 1)
end
TreeAI._FillMoreMenu = fillMenu
function TreeAI:GetMoreMenu() return menu, menuEntries end

function TreeAI:GetTabLayout() return tabRects end
function TreeAI:ToggleMoreMenu(v)
  if v == nil then v = not moreOpen end
  moreOpen = v and true or false
  if moreOpen and isMini() then local c = char(); if c then c.mini = false end end
  self:RefreshPanel()
  if moreOpen and panel and panel:IsShown() then
    fillMenu()
    if menu then menu:Show() end
  else
    closeMenu()
  end
  return moreOpen
end
function TreeAI:IsMoreMenuOpen() return moreOpen end

function TreeAI:CreatePanel()
  if panel or not _G.CreateFrame then return panel end
  local template = _G.BackdropTemplateMixin and "BackdropTemplate" or nil
  panel = _G.CreateFrame("Frame", "TreeAIPanel", _G.UIParent, template)
  panel:SetSize(DEFAULT_W, 40)
  panel:SetFrameStrata("MEDIUM")
  panel:SetClampedToScreen(true)
  panel:SetMovable(true)
  panel:EnableMouse(true)
  if panel.EnableMouseWheel then panel:EnableMouseWheel(true) end
  draggable(panel)
  if panel.SetBackdrop then
    panel:SetBackdrop({
      bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
      edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
      tile = true, tileSize = 16, edgeSize = 12,
      insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    panel:SetBackdropColor(0.05, 0.08, 0.06, 0.85)
    panel:SetBackdropBorderColor(0.2, 0.8, 0.4, 0.8)
  end
  panel:SetScript("OnMouseWheel", function(_, delta) TreeAI:ScrollTab(delta > 0 and -1 or 1) end)

  -- header: title (right-click = mini), mini line, toolbar
  local head = _G.CreateFrame("Button", nil, panel)
  head:SetHeight(HEADER_H)
  head:SetPoint("TOPLEFT", panel, "TOPLEFT", PAD, -2)
  head:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  draggable(head)
  panel.head = head
  local title = head:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  title:SetPoint("LEFT", head, "LEFT", 0, 0)
  title:SetText("|cff33cc66TreeAI|r")
  panel.title = title
  local miniText = head:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  miniText:SetPoint("LEFT", title, "RIGHT", 6, 0)
  miniText:SetPoint("RIGHT", head, "RIGHT", 0, 0)
  miniText:SetJustifyH("LEFT")
  if miniText.SetWordWrap then miniText:SetWordWrap(false) end
  panel.miniText = miniText
  head:SetScript("OnClick", function(_, button)
    if button == "RightButton" then TreeAI:ToggleMini(); return end
    if isMini() then
      local e = panel.miniEntry
      if e and e.onClick then runEntry(e, button) else TreeAI:SetMini(false) end
    end
  end)
  head:SetScript("OnEnter", function(self)
    if isMini() and panel.miniEntry then entryTooltip(self, panel.miniEntry)
    else
      local S = TreeAI.settings or {}
      showTooltip(self, "TreeAI Coach", {
        { L["Mode"] .. " : " .. L[(TreeAI.PRESET_LABEL or {})[S.preset or "normal"] or "Perso"] .. "  (/tai mode)", 0.4, 0.8, 1 },
        { L["Glisser : déplacer · clic droit : réduire/agrandir"], 0.6, 0.6, 0.6 },
        { L["/tai aide : toutes les commandes"], 0.6, 0.6, 0.6 } })
    end
  end)
  head:SetScript("OnLeave", hideTooltip)

  -- toolbar, right to left
  toolButton("close", L["Cacher le panneau (/tai afficher)"], function() TreeAI:HidePanel() end)
  toolButton("mini", function() return isMini() and L["Agrandir"] or L["Réduire à une ligne"] end,
    function() TreeAI:ToggleMini() end)
  toolButton("locked", function() local s = acc(); return s and s.locked and L["Déverrouiller"] or L["Verrouiller"] end,
    function()
      local s = acc(); if not s then return end
      s.locked = not s.locked
      TreeAI:RefreshPanel()
    end)
  toolButton("options", L["Options"], function() if TreeAI.OpenOptions then TreeAI:OpenOptions() end end)
  -- (Macros, Déplacer, Tout, Réinitialiser : dans le sous-menu « Plus », la barre reste courte)
  if TreeAI.Compass or (TreeAI.GetModule and TreeAI:GetModule("Compass")) then
    toolButton("compass", L["Boussole"], toggleCompass)
  end
  local x = -PAD + 2
  for _, b in ipairs(tools) do
    b:SetPoint("TOPRIGHT", panel, "TOPRIGHT", x, -4)
    x = x - 16
  end

  buildTabs()

  for i = 1, MAX_ROWS do
    rows[i] = makeRow(i)
    rows[i]:Hide()
  end
  panel.empty = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  panel.empty:SetJustifyH("LEFT")
  panel.thumb = panel:CreateTexture(nil, "OVERLAY")
  panel.thumb:SetTexture("Interface\\Buttons\\WHITE8X8")
  if panel.thumb.SetVertexColor then panel.thumb:SetVertexColor(0.2, 0.8, 0.4, 0.6) end
  panel.thumb:SetWidth(2)
  panel.more = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  panel.more:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -PAD - 14, 3)   -- place pour la poignée de largeur

  -- expire old suggestions even without new events ; (4.0.1) seulement panneau ouvert : le minuteur s'arrête quand
  -- le panneau se cache (la carte « Prochaine étape » suit les rendus) et repart quand il se montre
  local expiry
  local function startExpiry()
    if expiry then return end
    TreeAI._RunAs(nil, function()   -- minuteur du cœur (jamais coupé avec le module qui a ouvert le panneau)
      expiry = TreeAI:NewTicker(1, function()
        if not panel:IsShown() then if expiry then expiry:Cancel() end expiry = nil return end
        if TreeAI:PanelDirty() then TreeAI:RequestRefresh() else TreeAI:_UpdateGuide() end
      end)
    end)
  end
  if panel.HookScript then panel:HookScript("OnShow", startExpiry) end
  startExpiry()

  applyPosition()
  local s = acc()
  if s and s.shown == false then panel:Hide() else panel:Show() end
  self:RefreshPanel()
  return panel
end

local function renderMini()
  local e = TreeAI:GetTabLines("now")[1] or TreeAI:GetTabLines("quests")[1]
  panel.miniEntry = e
  if e then
    local c = PRIO_COLORS[e.prio] or PRIO_COLORS[1]
    panel.miniText:SetText(tostring(e.text))
    panel.miniText:SetTextColor(c[1], c[2], c[3])
  else
    panel.miniText:SetText(L["Rien à signaler."])
    panel.miniText:SetTextColor(0.5, 0.5, 0.5)
  end
end

-- barre de commandes d'un onglet : vrais petits boutons (largeur mesurée, 2 rangées max), infobulle = celle
-- de la ligne, clic = son onClick. Renvoie la hauteur prise (0 sans commande).
local ctrlButtons = {}
local ctrlRects = {}
local CTRL_H = 18
local function ctrlButton(i)
  local b = ctrlButtons[i]
  if b then return b end
  local template = _G.BackdropTemplateMixin and "BackdropTemplate" or nil
  b = _G.CreateFrame("Button", nil, panel, template)
  b:SetHeight(CTRL_H)
  b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  if b.SetBackdrop then
    b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    b:SetBackdropColor(0.14, 0.15, 0.19, 0.95)
    b:SetBackdropBorderColor(0.78, 0.62, 0.28, 0.45)
  end
  b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  b.text:SetPoint("CENTER", b, "CENTER", 0, 0)
  if b.text.SetWordWrap then b.text:SetWordWrap(false) end
  b.hl = b:CreateTexture(nil, "HIGHLIGHT")
  b.hl:SetAllPoints(b)
  b.hl:SetTexture("Interface\\Buttons\\WHITE8X8")
  if b.hl.SetVertexColor then b.hl:SetVertexColor(1, 1, 1, 0.12) end
  b:SetScript("OnClick", function(self, button) runEntry(self.entry, button) end)
  b:SetScript("OnEnter", function(self) if self.entry then entryTooltip(self, self.entry) end end)
  b:SetScript("OnLeave", hideTooltip)
  ctrlButtons[i] = b
  return b
end
local function layoutControls(list, width, top)
  for i = #ctrlRects, 1, -1 do ctrlRects[i] = nil end
  for _, b in ipairs(ctrlButtons) do b:Hide(); b.entry = nil end
  if #list == 0 then return 0 end
  local inner = width - 2 * PAD
  local x, row = PAD, 0
  for i, e in ipairs(list) do
    if row > 1 then break end
    local b = ctrlButton(i)
    b.entry = e
    local label = e.label or e.text
    local w = min(inner, floor((function() b.text:SetText(label); return b.text:GetStringWidth() or 40 end)() + 14))
    if x > PAD and x + w > PAD + inner then x, row = PAD, row + 1 end
    if row > 1 then b:Hide(); break end
    fitLabel(b.text, label, nil, w - 8)
    b:SetWidth(w)
    b:ClearAllPoints()
    b:SetPoint("TOPLEFT", panel, "TOPLEFT", x, -top - row * (CTRL_H + 2))
    b:Show()
    ctrlRects[#ctrlRects + 1] = { id = e.id, x = x, w = w, row = row, text = b.text:GetText(),
      textW = b.text:GetStringWidth() or 0, textMax = w - 8 }
    x = x + w + 3
  end
  return (row + 1) * (CTRL_H + 2) + 2
end
function TreeAI:GetTabControls() return ctrlRects end

-- ---------------------------------------------------------------- sections dans les onglets (rangé)
-- « Maintenant » : Urgent → Quête en cours → Ensuite ; autres onglets : un titre par bloc (module) quand il y en a
-- au moins deux. Les titres sont dessinés entre les lignes (pas des entrées : rien ne change pour les clics).
local SECTION_SRC = { Quests = "Étape conseillée", plan = "Trajet", main = nil, Auction = "Hôtel des ventes",
  missions = "Missions", Talents = "Talents", Squad = "Groupe", Missions = "Missions" }
local NOW_ICONS = { "Interface\\DialogFrame\\UI-Dialog-Icon-AlertNew", "Interface\\GossipFrame\\AvailableQuestIcon",
  "Interface\\Icons\\INV_Misc_Note_01" }
local BAND_ICONS = { step = "Interface\\GossipFrame\\AvailableQuestIcon", here = "Interface\\Icons\\INV_Misc_Map_01",
  near = "Interface\\Icons\\Ability_Rogue_Sprint", far = "Interface\\Minimap\\Tracking\\FlightMaster",
  misc = "Interface\\Icons\\INV_Misc_Spyglass_02" }
local function nowGroup(e)
  if e.prio >= 3 and not e.pin then return 1, L["Urgent"] end
  -- (COHERE) seule l'étape de quête (trajet / « Étape ») est « Quête en cours » ; les autres lignes épinglées
  -- (équipe, abandon, objet qui lance une quête) suivent : danger → étape → actions rapides → infos
  if e.pin and (TreeAI.STEP_SOURCES or {})[e.source or ""] then return 2, L["Quête en cours"] end
  if (e.prio or 1) >= 2 or e.pin then return 3, L["Ensuite"] end
  return 4, L["Infos"]
end
local function blockGroup(e, tab)
  if e._bandLabel then return "band:" .. tostring(e._band), e._bandLabel end
  local src = e.source
  if not src then return "~sugg", L["Conseils"] end
  if src == "main" then
    local owner = TreeAI.MAIN_OWNER and TreeAI.MAIN_OWNER[tab]
    local om = owner and TreeAI.modules and TreeAI.modules[owner]
    local t = TreeAI.tabs[tab]
    return "main", L[(om and om.title) or (t and t.title) or tab]
  end
  local m = TreeAI.modules and TreeAI.modules[src]
  return src, L[SECTION_SRC[src] or (m and m.title) or src]
end
TreeAI.PanelSectionOf = function(_, e, tab)
  if tab == "now" then return nowGroup(e) end
  return blockGroup(e, tab)
end
local function sectionIcon(g, e, tab)
  if tab == "now" then return NOW_ICONS[g] end
  if e._band then return BAND_ICONS[e._band] end
  return MODULE_ICONS[e.source or ""] or iconOf(e) or TAB_ICONS[tab]
end
local function region()
  local R = TreeAI.Region
  if type(R) == "table" and R.Arrange and (not R.IsEnabled or R:IsEnabled()) then return R end
  return nil
end
-- « Maintenant » : ordre logique stable (danger d'abord, puis l'étape de quête — celle de la zone actuelle
-- d'abord —, puis le reste par priorité)
local function orderNow(list)
  local R = region()
  for i, e in ipairs(list) do
    e._ord = i
    e._grp = nowGroup(e)
    e._rr = (R and e._grp == 2 and R.Rank) and select(2, pcall(R.Rank, e)) or 2
    if type(e._rr) ~= "number" then e._rr = 2 end
  end
  table.sort(list, function(a, b)
    if a._grp ~= b._grp then return a._grp < b._grp end
    if a._rr ~= b._rr then return a._rr < b._rr end
    return a._ord < b._ord
  end)
end
local secPool = {}
local function sectionFS(i)
  local fs = secPool[i]
  if not fs then
    fs = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    fs:SetJustifyH("LEFT")
    if fs.SetWordWrap then fs:SetWordWrap(false) end
    fs.rule = panel:CreateTexture(nil, "ARTWORK")
    fs.rule:SetTexture("Interface\\Buttons\\WHITE8X8")
    if fs.rule.SetVertexColor then fs.rule:SetVertexColor(0.2, 0.8, 0.4, 0.25) end
    fs.rule:SetHeight(1)
    secPool[i] = fs
  end
  return fs
end

-- MENU « meilleur guide » : distance · durée (colonne de droite) + direction / pourquoi (infobulle) de l'étape
-- en cours, lus sur la cible de la boussole (même contrat que Route / Compass) ou sur l'entrée du suivi.
local function guideFor(e)
  local C = TreeAI.Compass
  local G = type(C) == "table" and C.Geo
  if not G then return nil end
  local units = C.db and C.db.units
  local R = TreeAI.Region
  local qid = (R and R.QuestOf and R.QuestOf(e)) or e.questID
  local st = C.state
  local t = st and st.target
  if t and st.dist then
    local match = (qid and t.questID == qid)
    if not match and not qid and t.label then
      local lab = TreeAI.Cut(plainOf(t.label), 18, "")
      match = lab ~= "" and plainOf(e.text):find(lab, 1, true) ~= nil
    end
    if match then
      local dir = G.Cardinal and G.Cardinal(st.bearing) or ""
      local right = (st.approx and "≈" or "") .. G.Dist(st.dist, units) .. (st.eta and (" · " .. st.eta) or "")
      return right, ("Direction : %s · %s (boussole)"):format(dir ~= "" and dir or "?", right)
    end
  end
  local Tr = TreeAI.Tracker
  if qid and type(Tr) == "table" and Tr.items then
    for _, it in ipairs(Tr.items) do
      if it.key == qid and it.dist then
        local eta = it.travelSec and G.ETA and G.ETA(it.travelSec * 7, 7)
        local dir = (it.bearing and G.Cardinal) and G.Cardinal(it.bearing) or ""
        local right = G.Dist(it.dist, units) .. (eta and (" · " .. eta) or "")
        return right, ("Direction : %s · %s"):format(dir ~= "" and dir or "?", right)
      end
    end
  end
  return nil
end
TreeAI._GuideFor = guideFor

-- texte du panneau vide : « Rien d'urgent — continue « <quête> » »
local function emptyText(tab)
  if tab == "now" then
    local Td = TreeAI.Todo
    local a = Td and Td.model and Td.model.now
    local title = type(a) == "table" and a.questID and a.title
    local Tr = TreeAI.Tracker
    local top = Tr and Tr.shown and Tr.shown[1]
    if not title and type(top) == "table" and type(top.q) == "table" then title = top.q.title end
    if type(title) == "string" and title ~= "" and not isSecret(title) then
      -- (5.1 GLYPH) le titre de l'étape porte « (≈ 1 min) » : SafeText (titre jamais secret ici)
      return TreeAI.SafeText(L["Rien d'urgent"] .. " — " .. L["continue"] .. " « " .. plainOf(title) .. " »")
    end
  end
  return L[EMPTY[tab] or "Rien à signaler."]
end
TreeAI._EmptyText = emptyText

local visPool = {}
local CHEV_W, RIGHT_MAX = 10, 110
function TreeAI:RefreshPanel()
  if not panel then return end
  if TreeAI._PanelRendered then TreeAI:_PanelRendered() end
  -- (UIREDO) panneau caché (la carte « Prochaine étape » le remplace) : rien à dessiner ; ShowPanel le redessine
  if not panel:IsShown() then return end
  local s = acc()
  local width = panelWidth()
  panel:SetWidth(width)
  local mini = isMini()
  local fsize, gap, isize = look()
  tools.mini.tex:SetTexture(mini and ICONS.maxi or ICONS.mini)
  tools.locked.tex:SetTexture(s and s.locked and ICONS.locked or ICONS.unlocked)
  -- toolbar: only mini/close in mini mode
  local shownTools = 0
  for _, b in ipairs(tools) do
    local keep = not mini or b == tools.mini or b == tools.close
    if keep then b:Show(); shownTools = shownTools + 1 else b:Hide() end
  end
  panel.head:SetWidth(width - 2 * PAD - shownTools * 16 - 2)

  if mini then
    renderMini()
    panel.miniText:Show()
    for _, b in pairs(tabButtons) do b:Hide() end
    closeMenu()
    for _, b in ipairs(ctrlButtons) do b:Hide() end
    for i = 1, MAX_ROWS do rows[i].entry = nil; rows[i]:Hide() end
    for _, fs in ipairs(secPool) do fs:Hide(); fs.rule:Hide() end
    panel.empty:Hide(); panel.thumb:Hide(); panel.more:Hide()
    panel:SetHeight(HEADER_H + 6)
    return
  end
  panel.miniText:Hide()
  panel.miniEntry = nil

  buildTabs()
  local tabsH = layoutTabs(width)
  local tab = activeTab()
  local secUrgent = false
  for id, b in pairs(tabButtons) do
    if id ~= MORE and id ~= tab and not b:IsShown() then
      -- (3.9.9) onglet caché (rangée « Plus » fermée) : seule l'urgence compte, lue dans la pastille (≤ 1 fois / 2 s)
      local bt, br = badgeOf(id)
      if bt and br == 1 and isMoreTab(id) then secUrgent = true end
    elseif id ~= MORE then
      local list = self:GetTabLines(id)
      local urgent = false
      for _, e in ipairs(list) do if e.prio >= 3 then urgent = true break end end
      if urgent and isMoreTab(id) then secUrgent = true end
      if id == tab then b.text:SetTextColor(1, 1, 1); b.line:Show()
      elseif urgent then b.text:SetTextColor(1, 0.35, 0.3); b.line:Hide()
      elseif #list == 0 then b.text:SetTextColor(0.5, 0.5, 0.5); b.line:Hide()
      else b.text:SetTextColor(1, 0.82, 0); b.line:Hide() end
    end
  end
  local mb = tabButtons[MORE]
  if mb then
    if isMoreTab(tab) or moreOpen then mb.text:SetTextColor(1, 1, 1); mb.line:Show()
    elseif secUrgent or self.tabs.dungeon then mb.text:SetTextColor(1, 0.35, 0.3); mb.line:Hide()
    else mb.text:SetTextColor(1, 0.82, 0); mb.line:Hide() end
  end
  if moreOpen and menu and menu:IsShown() then fillMenu() end

  -- commandes de l'onglet (lignes control = true) : une barre de petits boutons sous les onglets
  local all = self:GetTabLines(tab)
  current = {}
  local ctrls = {}
  for _, e in ipairs(all) do
    if e.control then ctrls[#ctrls + 1] = e else current[#current + 1] = e end
  end
  if tab == "now" then orderNow(current)
  elseif tab == "quests" then
    local R = region()
    if R then
      local ok, out = pcall(R.Arrange, current)
      if ok and type(out) == "table" then current = out end
    end
  end
  tabsH = tabsH + layoutControls(ctrls, width, HEADER_H + tabsH + 2)
  local maxRows = min(MAX_ROWS, max(3, (s and s.maxLines) or 8))
  local n = #current
  local first = scroll[tab] or 1
  if first > n - maxRows + 1 then first = n - maxRows + 1 end
  if first < 1 then first = 1 end
  scroll[tab] = first
  local top = -(HEADER_H + tabsH + 4)
  local lineH = fsize + 4
  local Th = TreeAI.Theme
  local R = region()

  -- passe 1 : ce que chaque ligne visible affiche (genre, icône, couleur, texte, chiffres, mise en garde)
  local nVis, anyClick, colW = 0, false, 0
  local guided = false
  for i = 1, MAX_ROWS do
    local e = current[first + i - 1]
    if not (e and i <= maxRows) then break end
    nVis = i
    local v = visPool[i] or {}
    visPool[i] = v
    local kind = lineKind(e, tab)
    local kicon, r, g, b
    if Th and Th.LineStyle then kicon, r, g, b = Th:LineStyle(kind, e.prio)
    else local c = PRIO_COLORS[e.prio] or PRIO_COLORS[1]; r, g, b = c[1], c[2], c[3] end
    v.e, v.kind, v.r, v.g, v.b = e, kind, r, g, b
    v.icon = (KEEP_ICON[kind] and iconOf(e)) or kicon or iconOf(e)
    local txt, right = tostring(e.text), e.right
    if not right then
      if e._splitOf ~= txt then e._splitOf, e._splitT, e._splitR = txt, splitRight(txt) end
      txt, right = e._splitT, e._splitR
    end
    e._guide, e._note = nil, nil
    if tab == "now" and e.pin and not guided then   -- l'étape en cours : le meilleur guide
      guided = true
      local gr, gtip = guideFor(e)
      if gr then right, e._guide = gr, gtip end
      if R and R.NowNote then
        local ok, note = pcall(R.NowNote, e)
        if ok and type(note) == "string" then e._note = note end
      end
      v.guide = true
    else
      v.guide = false
    end
    if kind == "group" or tab == "group" then txt = colorNames(txt) end
    v.text, v.right, v.note = txt, right, e._note
    if e.onClick then anyClick = true end
    if right then
      local rf = rows[i].right
      rf:SetText(right)
      colW = max(colW, floor((rf:GetStringWidth() or 0) + 0.5))
    end
  end
  if colW > 0 then colW = min(RIGHT_MAX, colW) + 6 end
  local chevW = anyClick and CHEV_W or 0
  -- largeur utile du texte : panneau − marges − barre de défilement − icône − colonne de droite − chevron
  local rowW = width - 2 * PAD - 4
  local avail = rowW - (isize + 3) - colW - chevW

  local y = top
  local shown = 0
  -- sections : seulement s'il y a au moins deux groupes dans l'onglet
  local groups, nG = {}, 0
  for _, e in ipairs(current) do
    local g = TreeAI:PanelSectionOf(e, tab)
    if not groups[g] then groups[g] = 0; nG = nG + 1 end
    if e.questID then groups[g] = groups[g] + 1 end
  end
  local lastG, nSec = nil, 0
  local secH = fsize + 5
  for i = 1, MAX_ROWS do
    local b, v = rows[i], (i <= nVis) and visPool[i] or nil
    local e = v and v.e
    if e then
      shown = shown + 1
      local g, gl = TreeAI:PanelSectionOf(e, tab)
      if nG > 1 and g ~= lastG and gl then
        nSec = nSec + 1
        local fs = sectionFS(nSec)
        local font, _, flags = fs:GetFont()
        if font then fs:SetFont(font, max(9, fsize - 1), flags) end
        fs:ClearAllPoints()
        fs:SetPoint("TOPLEFT", panel, "TOPLEFT", PAD, y - 1)
        fs:SetWidth(width - 2 * PAD - 4)
        local sic = sectionIcon(g, e, tab)
        local cnt = (tab == "quests" and (groups[g] or 0) > 0) and (" |cff888888(" .. groups[g] .. ")|r") or ""
        local col = (tab == "now" and g == 1) and "|cffff4d40" or "|cff33cc66"
        fs:SetText((sic and ("|T" .. sic .. ":" .. (fsize + 1) .. ":" .. (fsize + 1) .. "|t ") or "") .. col .. tostring(gl) .. "|r" .. cnt)
        fs:Show()
        fs.rule:ClearAllPoints()
        fs.rule:SetPoint("TOPLEFT", panel, "TOPLEFT", PAD, y - secH + 1)
        fs.rule:SetWidth(width - 2 * PAD - 4)
        fs.rule:Show()
        y = y - secH - 1
      end
      lastG = g
      b.entry = e
      local font, _, flags = b.text:GetFont()
      if font then b.text:SetFont(font, fsize, flags); b.right:SetFont(font, max(9, fsize - 1), flags) end
      -- nombre de lignes : texte mesuré / largeur utile (retour à la ligne, jamais « … »), + la mise en garde
      b.text:SetText(v.text)
      local tw = (b.text.GetUnboundedStringWidth and b.text:GetUnboundedStringWidth()) or b.text:GetStringWidth() or 0
      -- (+8 % : le retour à la ligne se fait au mot, la dernière ligne n'est jamais pleine)
      local nl = min(3, max(1, math.ceil((tw * 1.08 + 2) / max(40, avail))))
      local nn = 0
      if v.note then
        b.text:SetText(v.note)
        local nw = (b.text.GetUnboundedStringWidth and b.text:GetUnboundedStringWidth()) or b.text:GetStringWidth() or 0
        nn = min(2, max(1, math.ceil((nw * 1.08 + 2) / max(40, avail))))
        b.text:SetText(v.text .. "\n|cffff9933" .. v.note .. "|r")
      end
      b.text:SetTextColor(v.r, v.g, v.b)
      local h = (nl + nn) * lineH
      b.lines = nl + nn
      b:SetHeight(h)
      b.text:SetHeight(h)
      b.text:SetWidth(avail)
      b:ClearAllPoints()
      b:SetPoint("TOPLEFT", panel, "TOPLEFT", PAD, y)
      b:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -PAD - 4, y)
      b.icon:SetSize(isize, isize)
      if v.icon then b.icon:SetTexture(v.icon); b.icon:Show() else b.icon:Hide() end
      b.text:ClearAllPoints()
      b.text:SetPoint("TOPLEFT", b, "TOPLEFT", isize + 3, 0)
      b.text:SetPoint("TOPRIGHT", b, "TOPRIGHT", -(colW + chevW), 0)
      b.right:ClearAllPoints()
      if v.right and colW > 0 then
        b.right:SetText(v.right)
        b.right:SetWidth(colW - 4)
        b.right:SetPoint("TOPRIGHT", b, "TOPRIGHT", -chevW, -1)
        b.right:SetTextColor(v.guide and 0.55 or 0.75, v.guide and 0.85 or 0.85, 1)
        b.right:Show()
      else
        b.right:SetText("")
        b.right:Hide()
      end
      if e.onClick then b.chev:Show() else b.chev:Hide() end
      b._geo = { kind = v.kind, icon = v.icon, r = v.r, g = v.g, b = v.b, textPx = tw, avail = avail, lines = nl,
        noteLines = nn, right = v.right, rightPx = v.right and (b.right:GetStringWidth() or 0) or 0,
        rightW = colW > 0 and (colW - 4) or 0, rowW = rowW, iconW = isize + 3, colW = colW, chevW = chevW,
        clickable = e.onClick ~= nil, guide = v.guide, note = v.note, text = v.text }
      b:Show()
      y = y - h - gap
    else
      b.entry = nil
      b._geo = nil
      b:Hide()
    end
  end
  for i = 1, nVis do visPool[i].e = nil end
  for i = nSec + 1, #secPool do secPool[i]:Hide(); secPool[i].rule:Hide() end
  panel.sections = nSec
  if shown == 0 then
    panel.empty:ClearAllPoints()
    panel.empty:SetPoint("TOPLEFT", panel, "TOPLEFT", PAD, top - 1)
    panel.empty:SetWidth(width - 2 * PAD - 4)
    if panel.empty.SetWordWrap then panel.empty:SetWordWrap(true) end
    panel.empty:SetText(emptyText(tab))
    panel.empty:Show()
    local ew = panel.empty:GetStringWidth() or 0
    y = top - lineH * min(2, max(1, math.ceil((ew + 1) / max(40, width - 2 * PAD - 4))))
  else
    panel.empty:Hide()
  end
  local bodyH = top - y
  panel:SetHeight(-y + 8 + (n > maxRows and 10 or 0))
  if n > maxRows then
    local th = max(8, floor(bodyH * maxRows / n))
    local off = floor((bodyH - th) * (first - 1) / max(1, n - maxRows))
    panel.thumb:ClearAllPoints()
    panel.thumb:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -PAD + 2, top - off)
    panel.thumb:SetHeight(th)
    panel.thumb:Show()
    panel.more:SetText(("%d-%d/%d"):format(first, min(n, first + maxRows - 1), n))
    panel.more:Show()
  else
    panel.thumb:Hide()
    panel.more:Hide()
  end
end

-- MENU : distance / durée de l'étape en cours tenues à jour sans redessiner le panneau (ticker 1 s existant)
function TreeAI:_UpdateGuide()
  if not (panel and panel:IsShown()) or isMini() or activeTab() ~= "now" then return false end
  for i = 1, MAX_ROWS do
    local b = rows[i]
    local gm = b and b.entry and b._geo
    if gm and gm.guide and b:IsShown() then
      local gr, gtip = guideFor(b.entry)
      if gr and gr ~= gm.right then
        if gm.colW == 0 or not gm.right then self:RequestRefresh() return true end
        b.entry._guide = gtip
        gm.right = gr
        b.right:SetText(gr)
        return true
      end
      return false
    end
  end
  return false
end

-- géométrie des lignes visibles (tests) : { {top, h, lines}, ... }
function TreeAI:GetRowLayout()
  local out = {}
  for i = 1, MAX_ROWS do
    local b = rows[i]
    if b and b.entry and b:IsShown() then
      local _, _, _, _, yy = b:GetPoint(1)
      local r = { top = yy, h = b:GetHeight(), lines = b.lines }
      for k, v in pairs(b._geo or {}) do if r[k] == nil then r[k] = v end end
      out[#out + 1] = r
    end
  end
  return out
end

function TreeAI:ScrollTab(step)
  local tab = activeTab()
  scroll[tab] = (scroll[tab] or 1) + (step or 1)
  self:RefreshPanel()
end

function TreeAI:SelectTab(id)
  if not self.tabs[id] then return false end
  local c = char()
  if c then c.tab = id; c.mini = false end
  closeMenu()
  if not panel then self:CreatePanel() end
  if panel and not panel:IsShown() then self:ShowPanel() end
  self:RefreshPanel()
  return true
end

function TreeAI:GetActiveTab() return activeTab() end
function TreeAI:GetVisibleLines() return current end

function TreeAI:SetMini(v)
  local c = char()
  if c then c.mini = v and true or false end
  self:RefreshPanel()
end
function TreeAI:ToggleMini() self:SetMini(not isMini()) end
function TreeAI:IsMini() return isMini() end

function TreeAI:ShowPanel()
  if not panel then self:CreatePanel() end
  if panel then panel:Show(); self:RefreshPanel() end
  local s = acc(); if s then s.shown = true end
end

function TreeAI:HidePanel()
  closeMenu()
  if panel then panel:Hide() end
  local s = acc(); if s then s.shown = false end
end

function TreeAI:TogglePanel()
  if panel and panel:IsShown() then self:HidePanel() else self:ShowPanel() end
end

function TreeAI:ResetPanel()
  local s, c = acc(), char()
  if not s then return end
  s.scale, s.alpha = 1, 0.9
  if c then c.point, c.x, c.y, c.manual = "CENTER", 300, 120, nil end
  applyPosition()
  -- « réinitialiser » = retour au placement automatique (zones libres de l'écran)
  if self.ResetMovable then self:ResetMovable("panel") end
end

-- position rapide (assistant) : "TOPRIGHT", "RIGHT", "BOTTOMRIGHT", "BOTTOMLEFT", "CENTER"
TreeAI.PANEL_SPOTS = {
  TOPRIGHT = { "TOPRIGHT", -40, -240 }, RIGHT = { "RIGHT", -40, 0 }, BOTTOMRIGHT = { "BOTTOMRIGHT", -40, 220 },
  BOTTOMLEFT = { "BOTTOMLEFT", 40, 220 }, CENTER = { "CENTER", 300, 120 },
}
function TreeAI:SetPanelPosition(spot)
  local p, c = self.PANEL_SPOTS[spot], char()
  if not (p and c) then return false end
  c.point, c.x, c.y = p[1], p[2], p[3]
  c.manual = true   -- (PLACEBUG) le choix du joueur (assistant) : aucun placement automatique ne le reprend
  if not panel then self:CreatePanel() end
  applyPosition()
  return true
end

function TreeAI:ApplyPanelSettings()
  applyPosition()
  self:RefreshPanel()
  if self.ApplyAlertSettings then self:ApplyAlertSettings() end
end

function TreeAI:GetPanel() return panel end

---------------------------------------------------------------------------
-- Corner alert box: important (prio 3) items only, 1-2 lines, fades out, click = open the panel tab
---------------------------------------------------------------------------
local CORNERS = {
  TOPRIGHT = { -24, -210 },   -- under the minimap
  TOPLEFT = { 24, -110 },
  BOTTOMLEFT = { 24, 210 },
  BOTTOMRIGHT = { -24, 160 },
}
TreeAI.ALERT_CORNERS = { "TOPRIGHT", "TOPLEFT", "BOTTOMLEFT", "BOTTOMRIGHT" }
local alertItems = {}

local function alertSettings() return TreeAI.settings and TreeAI.settings.alert end

local function makeAlert()
  if alert or not _G.CreateFrame then return alert end
  local template = _G.BackdropTemplateMixin and "BackdropTemplate" or nil
  alert = _G.CreateFrame("Button", "TreeAIAlert", _G.UIParent, template)
  alert:SetSize(300, 22)   -- (4.0 QA) 230 px coupait « Fais de la place : sacs pleins, le butin est p… »
  alert:SetFrameStrata("HIGH")
  alert:SetClampedToScreen(true)
  alert:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  if alert.SetBackdrop then
    alert:SetBackdrop({
      bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
      edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
      tile = true, tileSize = 16, edgeSize = 10,
      insets = { left = 2, right = 2, top = 2, bottom = 2 },
    })
    alert:SetBackdropColor(0.15, 0.03, 0.02, 0.85)
    alert:SetBackdropBorderColor(1, 0.3, 0.25, 0.9)
  end
  alert.lines = {}
  for i = 1, 2 do
    local fs = alert:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    fs:SetPoint("TOPLEFT", alert, "TOPLEFT", 7, -5 - (i - 1) * 13)
    fs:SetPoint("TOPRIGHT", alert, "TOPRIGHT", -7, -5 - (i - 1) * 13)
    fs:SetJustifyH("LEFT")
    if fs.SetWordWrap then fs:SetWordWrap(false) end
    fs:SetTextColor(1, 0.45, 0.4)
    alert.lines[i] = fs
  end
  alert:SetScript("OnClick", function(_, button)
    local it = alertItems[1]
    alert:Hide()
    if button == "RightButton" then return end
    local tab = it and it.tab or "now"
    TreeAI:SelectTab(TreeAI.tabs[tab] and tab or "now")
  end)
  alert:SetScript("OnEnter", function(self)
    self.hold = true
    self:SetAlpha((alertSettings() or {}).alpha or 0.95)
    showTooltip(self, L["Important"], { { L["Clic : ouvrir la page · clic droit : fermer"], 0.6, 0.6, 0.6 } })
  end)
  alert:SetScript("OnLeave", function(self) self.hold = false; hideTooltip() end)
  alert:SetScript("OnHide", function() for i = #alertItems, 1, -1 do alertItems[i] = nil end end)
  alert:SetScript("OnUpdate", function(self, dt)
    if self.hold then return end
    self.left = (self.left or 0) - (dt or 0)
    local a = (alertSettings() or {}).alpha or 0.95
    if self.left <= 0 then self:Hide()
    elseif self.left < 1 then self:SetAlpha(a * self.left) end
  end)
  alert:Hide()
  return alert
end

function TreeAI:ApplyAlertSettings()
  local s = alertSettings()
  if not (alert and s) then return end
  alert:ClearAllPoints()
  if type(s.pos) == "table" and not validAnchor(s.pos.point, s.pos.x, s.pos.y) then s.pos = nil end  -- (PLACEBUG) incomplète
  local pos = type(s.pos) == "table" and s.pos.corner == s.corner and s.pos  -- auto / édition
  if pos then
    alert:SetPoint(pos.point, _G.UIParent, pos.point, pos.x, pos.y)
  else
    local corner = CORNERS[s.corner] and s.corner or "TOPRIGHT"
    local off = CORNERS[corner]
    alert:SetPoint(corner, _G.UIParent, corner, off[1], off[2])
  end
  alert:SetScale(s.scale or 1)
end

-- e = suggestion or { text=, prio=3, tab=? }; force shows it even when the box is disabled (test)
function TreeAI:ShowAlert(e, force)
  local s = alertSettings()
  if not e or not e.text or (not force and (not s or s.enabled == false or (e.prio or 0) < 3)) then return end
  if not makeAlert() then return end
  local tab = e.tab
  if not tab and self.TabOf and e.time then tab = self:TabOf(e) end
  for i = #alertItems, 1, -1 do
    if (e.id and alertItems[i].id == e.id) or alertItems[i].text == e.text then table.remove(alertItems, i) end
  end
  table.insert(alertItems, 1, { id = e.id, text = tostring(e.text), tab = tab })
  for i = #alertItems, 3, -1 do alertItems[i] = nil end
  for i = 1, 2 do
    local it = alertItems[i]
    alert.lines[i]:SetText(it and it.text or "")
    if it then alert.lines[i]:Show() else alert.lines[i]:Hide() end
  end
  alert:SetHeight(10 + 13 * #alertItems)
  self:ApplyAlertSettings()
  alert.left = (s and s.duration) or 8
  local wasShown = alert:IsShown()
  alert:SetAlpha((s and s.alpha) or 0.95)
  alert:Show()
  -- fondu d'entrée (une seule fois à l'ouverture, pas à chaque nouvelle ligne)
  if not wasShown and self.Theme and self.Theme.Animate then self.Theme:Animate(alert, 0, (s and s.alpha) or 0.95, 0.2) end
end

function TreeAI:GetAlert() return alert, alertItems end

---------------------------------------------------------------------------
-- Placement automatique de NOS cadres (panneau, encadré d'alerte, boussole, suivi, barres chasseur).
-- 1. scan en LECTURE SEULE de l'écran : cadres connus (minimap, barres, chat, suivi des quêtes, cadres
--    d'unité, Details/Recount/Bartender/ElvUI…) + cadres visibles enfants d'UIParent (EnumerateFrames),
--    IsVisible + GetRect, sans les cadres plein écran / cachés / minuscules / les nôtres ;
-- 2. grille d'occupation (cases de 16 unités d'interface, échelle d'UI respectée) ;
-- 3. chaque rôle prend le meilleur rectangle libre près de sa cible (taille adaptée à la place).
-- Jamais un cadre de Blizzard ou d'un autre addon n'est déplacé ; hors combat seulement.
-- Un cadre déplacé à la main garde sa place (« réinitialiser » / « Placer automatiquement » le rendent).
---------------------------------------------------------------------------
local CELL = 16
-- (4.4 SMART) placement automatique découpé : lancé par le pilote du placement (connexion, résolution changée), il
-- tourne dans une coroutine qui rend la main toutes les LAYOUT_SLICE unités de travail (≈ 1,5 ms) → plus d'image de
-- 70 ms à la connexion. Appelé directement (bouton « Placer », tests), il reste d'un seul tenant.
TreeAI.LAYOUT_SLICE = 1200
local LAY = { co = nil, n = 0 }   -- (une seule locale : le fichier est au plafond des 200 locales de Lua 5.1)
function LAY.yield(units)
  LAY.n = LAY.n + units
  if LAY.n >= TreeAI.LAYOUT_SLICE and coroutine.running() == LAY.co then LAY.n = 0 coroutine.yield() end
end
local SCAN_NAMES = {
  "MinimapCluster", "Minimap", "MinimapBackdrop", "MainMenuBar", "MainMenuBarArtFrame", "MainActionBar",
  "MultiBarBottomLeft", "MultiBarBottomRight", "MultiBarRight", "MultiBarLeft", "MultiBar5", "MultiBar6",
  "MultiBar7", "StanceBar", "StanceBarFrame", "PetActionBar", "PetActionBarFrame", "MicroButtonAndBagsBar",
  "MicroMenuContainer", "BagsBar", "MainMenuExpBar", "ReputationWatchBar", "StatusTrackingBarManager",
  "MainStatusTrackingBarContainer", "GeneralDockManager", "ChatFrameMenuButton", "QuickJoinToastButton",
  "ObjectiveTrackerFrame", "QuestWatchFrame", "WatchFrame", "QuestTimerFrame", "Questie_BaseFrame",
  "QuestieTrackerBaseFrame", "PlayerFrame", "TargetFrame", "TargetFrameToT", "FocusFrame", "PetFrame",
  "PartyFrame", "PartyMemberFrame1", "PartyMemberFrame2", "PartyMemberFrame3", "PartyMemberFrame4",
  "CompactPartyFrame", "CompactRaidFrameContainer", "BuffFrame", "DebuffFrame", "TemporaryEnchantFrame",
  "CastingBarFrame", "PlayerCastingBarFrame", "DurabilityFrame", "VehicleSeatIndicator", "UIWidgetTopCenterContainerFrame",
  "DetailsBaseFrame1", "DetailsBaseFrame2", "Details_BaseFrame1", "Recount_MainWindow", "SkadaBarWindowSkada",
  "ElvUI_Bar1", "ElvUI_Bar2", "ElvUI_Bar3", "ElvUI_Bar4", "ElvUI_Bar5", "ElvUI_Bar6", "ElvUF_Player",
  "ElvUF_Target", "ElvUF_Party", "LeftChatPanel", "RightChatPanel", "MMHolder", "ElvUI_MinimapHolder",
  "BT4Bar1", "BT4Bar2", "BT4Bar3", "BT4Bar4", "BT4Bar5", "BT4Bar6", "BT4Bar7", "BT4Bar8", "BT4Bar9", "BT4Bar10",
  "BT4BarMicroMenu", "BT4BarBagBar", "BT4BarStanceBar", "BT4BarPetBar",
}
for _, n in ipairs({
  -- boutons autour de la minimap
  "MiniMapTracking", "MiniMapTrackingFrame", "MinimapZoneTextButton", "MinimapBorderTop", "GameTimeFrame",
  "TimeManagerClockButton", "MiniMapMailFrame", "MinimapZoomIn", "MinimapZoomOut", "MiniMapWorldMapButton",
  "MiniMapBattlefieldFrame", "MiniMapLFGFrame", "MinimapToggleButton", "ExpansionLandingPageMinimapButton",
  -- suivis de quêtes (Questie…), compteurs (Details / Recount / Skada), raid, barres spéciales
  "Questie_BaseFrame", "QuestieTrackerBaseFrame", "Questie_TrackerBaseFrame", "QuestieTracker_BaseFrame",
  "Questie_HeaderFrame", "Questie_TrackedQuests", "DetailsBaseFrame3", "Details_BaseFrame2", "Recount_DetailWindow",
  "CompactRaidFrameManager", "ExtraActionBarFrame", "ZoneAbilityFrame", "ChatFrame1EditBox", "PlayerPowerBarAlt",
  -- (COHERE) Shortest Path Forever : colonne « Suivi Forever » (nettoyer le journal, trajet, composants) ;
  -- noms probables, le préfixe ci-dessous attrape les autres (lecture seule, jamais déplacés)
  "ShortestPathForeverTracker", "ShortestPathForeverTrackerFrame", "ShortestPathForeverFrame",
  "ShortestPathForever_Tracker", "ShortestPathForeverTrackerBaseFrame", "SPFTrackerFrame", "SPF_TrackerFrame",
  "SPF_Tracker", "ShortestPathTrackerFrame",
}) do SCAN_NAMES[#SCAN_NAMES + 1] = n end
for i = 1, 10 do SCAN_NAMES[#SCAN_NAMES + 1] = "ChatFrame" .. i end
SCAN_NAMES[#SCAN_NAMES + 1] = "TreeAIWatchFrame"   -- (REPLACE 4.0.1) Suivi TreeAI : mesuré comme un suivi (voir isOurs)
TreeAI.LAYOUT_SCAN_NAMES = SCAN_NAMES
-- cadres d'autres addons repérés par leur préfixe (enfants de la minimap compris : boutons LibDBIcon)
local SCAN_PREFIX = { "LibDBIcon10_", "Questie_", "QuestieTracker", "Details", "Recount", "Skada",
  "CompactRaid", "CompactParty", "PartyMemberFrame", "ShortestPath", "SPF_", "SPFTracker" }
-- (COHERE) suivis d'autres addons : leur cadre racine peut être une petite ancre dont les lignes pendent
-- dessous -> rectangle = union des enfants visibles ; et ils grandissent comme un suivi de quêtes
local GUIDE_PREFIX = { "ShortestPath", "SPF_", "SPFTracker", "Questie" }
local function guideName(n)
  if type(n) ~= "string" then return false end
  for _, p in ipairs(GUIDE_PREFIX) do if n:sub(1, #p) == p then return true end end
  return false
end
local function trackerish(n)
  if not guideName(n) then return false end
  local l = n:lower()
  return (l:find("track") or l:find("suivi") or l:find("list") or l:find("base")) and true or false
end
TreeAI.LAYOUT_GUIDE_PREFIX = GUIDE_PREFIX
TreeAI.LAYOUT_SCAN_PREFIX = SCAN_PREFIX
-- suivis de quêtes : ils grandissent avec les quêtes -> on réserve la colonne jusqu'au tiers bas de l'écran
local GROWS = { ObjectiveTrackerFrame = true, QuestWatchFrame = true, WatchFrame = true, Questie_BaseFrame = true,
  QuestieTrackerBaseFrame = true, Questie_TrackerBaseFrame = true, QuestieTracker_BaseFrame = true,
  Questie_TrackedQuests = true, TreeAIWatchFrame = true }
-- cadres de groupe : réservés même cachés (le groupe se forme plus tard, ils ne doivent pas tomber sur nous)
local RESERVE_HIDDEN = { PartyMemberFrame1 = true, PartyMemberFrame2 = true, PartyMemberFrame3 = true,
  PartyMemberFrame4 = true, CompactPartyFrame = true, PartyFrame = true }
local PARTY_NAMES = { "PartyMemberFrame1", "PartyMemberFrame2", "PartyMemberFrame3", "PartyMemberFrame4",
  "CompactPartyFrame", "PartyFrame", "CompactRaidFrameContainer", "ElvUF_Party" }
local TRACKER_NAMES = { "ObjectiveTrackerFrame", "QuestWatchFrame", "WatchFrame", "Questie_BaseFrame",
  "QuestieTrackerBaseFrame", "Questie_TrackerBaseFrame", "QuestieTracker_BaseFrame", "Questie_TrackedQuests" }
local function hasPrefix(n)
  if type(n) ~= "string" then return false end
  for _, p in ipairs(SCAN_PREFIX) do if n:sub(1, #p) == p then return true end end
  return false
end
local SKIP_STRATA = { BACKGROUND = true, FULLSCREEN = true, FULLSCREEN_DIALOG = true, TOOLTIP = true }

local function call(f, m, ...)
  local fn = f and f[m]
  if type(fn) ~= "function" then return nil end
  local ok, a, b, c, d = pcall(fn, f, ...)
  if ok then return a, b, c, d end
end

--- (PLACEBUG) pose f à (point, x, y) d'UIParent (même point des deux côtés) ; échec = l'ancrage d'avant est remis
local function setAnchor(f, point, x, y, scale)
  if type(f) ~= "table" or type(f.SetPoint) ~= "function" or not validAnchor(point, x, y) then return false end
  if finite(scale) and scale > 0.05 and scale < 10 then call(f, "SetScale", scale) end
  local keep = {}
  for i = 1, math.min(tonumber(call(f, "GetNumPoints")) or 0, 8) do
    local ok, a, b, c, d, e = pcall(f.GetPoint, f, i)
    if ok and a then keep[#keep + 1] = { a, b, c, d, e } end
  end
  call(f, "ClearAllPoints")
  local ok = pcall(f.SetPoint, f, point, _G.UIParent, point, x, y)
  if not ok then for _, p in ipairs(keep) do pcall(f.SetPoint, f, p[1], p[2], p[3], p[4], p[5]) end end
  return ok
end
TreeAI.SetAnchor = function(_, f, point, x, y, scale) return setAnchor(f, point, x, y, scale) end

--- taille d'UIParent en unités d'interface, ou nil tant qu'elle n'est pas valide (à la connexion, UIParent n'a
--- pas encore sa taille : jamais de repli inventé « 1920×1080 » sur lequel placer quoi que ce soit)
local function screenSize()
  local P = _G.UIParent
  local w, h = call(P, "GetWidth"), call(P, "GetHeight")
  if not (finite(w) and finite(h) and w > 200 and h > 200) then
    local okW, sw = pcall(_G.GetScreenWidth or error)
    local okH, sh = pcall(_G.GetScreenHeight or error)
    w, h = okW and tonumber(sw) or nil, okH and tonumber(sh) or nil
    if not (finite(w) and finite(h) and w > 200 and h > 200) then return nil end
  end
  return w, h
end
TreeAI._ScreenSize = screenSize

local function layoutState()
  local c = TreeAI.db and TreeAI:CharKey() ~= "?" and TreeAI:CharDB() or nil
  local st = c and c.layout
  if c and type(st) ~= "table" then st = { manual = {} }; c.layout = st end
  st = st or TreeAI._layoutTmp or { manual = {} }
  TreeAI._layoutTmp = st
  st.manual = type(st.manual) == "table" and st.manual or {}
  return st
end

local function isOurs(f)
  -- (REPLACE 4.0.1) le Suivi TreeAI se mesure comme un suivi de quêtes : rien ne se pose sur lui (carte, panneau)
  if type(f) == "table" and rawget(f, "_taiScan") then return false end
  if f == panel or f == alert then return true end
  if type(f) == "table" and rawget(f, "_taiOurs") then return true end   -- (PLACEBUG) nos cadres sans nom (calques)
  local n = call(f, "GetName")
  return type(n) == "string" and n:sub(1, 6) == "TreeAI"
end

-- rectangle d'un cadre en unités d'UIParent (gauche, bas, largeur, hauteur) ou nil
local function rectOf(f, W, H, evenHidden)
  if type(f) ~= "table" or isOurs(f) then return nil end
  if call(f, "IsForbidden") then return nil end
  if not evenHidden and not call(f, "IsVisible") then return nil end
  local l, b, w, h = call(f, "GetRect")
  if not (l and b and w and h) or w < 12 or h < 8 then return nil end
  local k = (call(f, "GetEffectiveScale") or 1) / (call(_G.UIParent, "GetEffectiveScale") or 1)
  l, b, w, h = l * k, b * k, w * k, h * k
  if w >= W * 0.9 and h >= H * 0.6 then return nil end      -- plein écran (conteneurs, ElvUIParent…)
  if SKIP_STRATA[call(f, "GetFrameStrata") or ""] then return nil end
  local a = call(f, "GetEffectiveAlpha") or call(f, "GetAlpha") or 1
  if a < 0.05 and not evenHidden then return nil end
  if l + w < 0 or b + h < 0 or l > W or b > H then return nil end
  return { l = l, b = b, w = w, h = h, name = call(f, "GetName") }
end
-- (COHERE) union des enfants visibles (≤ 60, un niveau) d'un cadre de suivi d'un autre addon
local function childUnion(f, W, H)
  if type(f) ~= "table" or type(f.GetChildren) ~= "function" or not call(f, "IsVisible") then return nil end
  local kids = { pcall(f.GetChildren, f) }
  if not kids[1] then return nil end
  local l0, b0, r0, t0
  for i = 2, math.min(#kids, 61) do
    local r = rectOf(kids[i], W, H)
    if r then
      l0, b0 = math.min(l0 or r.l, r.l), math.min(b0 or r.b, r.b)
      r0, t0 = math.max(r0 or (r.l + r.w), r.l + r.w), math.max(t0 or (r.b + r.h), r.b + r.h)
    end
  end
  if not l0 then return nil end
  return { l = l0, b = b0, w = r0 - l0, h = t0 - b0, name = call(f, "GetName") }
end
local function guideRect(f, W, H, name)
  local r = rectOf(f, W, H)
  if guideName(name) then
    local u = childUnion(f, W, H)
    if u and (not r or u.w * u.h > r.w * r.h) then r = u end
  end
  return r
end
TreeAI._GuideRect = guideRect
TreeAI._discovered = TreeAI._discovered or {}   -- noms de cadres d'addons trouvés par préfixe (reflow léger)

--- Scan lecture seule. Renvoie { W=, H=, rects = { {l,b,w,h,name}... }, named = { [name] = rect } }.
--- (PLACEBUG) écran pas encore posé (connexion) : { W = 0, H = 0, rects = {}, named = {}, notReady = true }.
function TreeAI:ScanScreen()
  local W, H = screenSize()
  if not W then return { W = 0, H = 0, rects = {}, named = {}, notReady = true } end
  local rects, named, seen = {}, {}, {}
  local function add(f, name)
    if seen[f] then return end
    seen[f] = true
    name = name or call(f, "GetName")
    local r = guideRect(f, W, H, name)
    if not r and name and RESERVE_HIDDEN[name] then r = rectOf(f, W, H, true); if r then r.hidden = true end end
    if r and guideName(name) then TreeAI._discovered[name] = true end
    if r then
      if r.name and (GROWS[r.name] or trackerish(r.name)) then
        -- la colonne du suivi jusqu'au tiers bas (au moins 250 de large, côté de l'écran conservé)
        local top = r.b + r.h
        local bottom = math.min(r.b, math.max(H * 0.30, top - 560))
        local w = math.max(r.w, 250)
        local l = (r.l + r.w / 2 > W / 2) and math.min(r.l, r.l + r.w - w) or r.l
        r = { l = l, b = bottom, w = w, h = top - bottom, name = r.name, grown = true }
      end
      rects[#rects + 1] = r
      if r.name then named[r.name] = r end
    end
  end
  for _, n in ipairs(SCAN_NAMES) do
    local f = _G[n]
    if type(f) == "table" then add(f, n) end
  end
  if type(_G.EnumerateFrames) == "function" then
    local ok = pcall(function()
      local f, guard = _G.EnumerateFrames(), 0
      while f and guard < 20000 do
        guard = guard + 1
        if call(f, "GetParent") == _G.UIParent or hasPrefix(call(f, "GetName")) then add(f) end
        f = _G.EnumerateFrames(f)
      end
    end)
    if not ok then self:Debug("scan: EnumerateFrames") end
  end
  return { W = W, H = H, rects = rects, named = named }
end

-- grille d'occupation + sommes cumulées (test « rectangle libre » en O(1))
local function newGrid(scan)
  local cols, rowsN = math.floor(scan.W / CELL), math.floor(scan.H / CELL)
  local g = { cols = cols, rows = rowsN, occ = {} }
  for i = 1, cols * rowsN do g.occ[i] = 0 end
  function g.mark(r, margin)
    margin = margin or 0
    local c0 = math.max(0, math.floor((r.l - margin) / CELL))
    local c1 = math.min(cols - 1, math.floor((r.l + r.w + margin - 1) / CELL))
    local r0 = math.max(0, math.floor((r.b - margin) / CELL))
    local r1 = math.min(rowsN - 1, math.floor((r.b + r.h + margin - 1) / CELL))
    if r1 < r0 or c1 < c0 then return end
    for y = r0, r1 do for x = c0, c1 do g.occ[y * cols + x + 1] = 1 end end
    -- (4.4 SMART) sommes cumulées gardées : seule la partie en haut à droite de (r0, c0) sera recalculée
    if g.sum then g.dr0, g.dc0 = math.min(g.dr0 or r0, r0), math.min(g.dc0 or c0, c0) end
  end
  local function refresh()   -- recalcul partiel : lignes ≥ dr0, colonnes ≥ dc0 (le reste n'a pas bougé)
    local S, W1, occ, c0 = g.sum, g.W1, g.occ, g.dc0
    for y = g.dr0 + 1, rowsN do
      local run = S[y * W1 + c0] - S[(y - 1) * W1 + c0]
      for x = c0 + 1, cols do
        run = run + occ[(y - 1) * cols + x]
        S[y * W1 + x] = S[(y - 1) * W1 + x] + run
      end
      if LAY.co then LAY.yield(cols - c0) end
    end
    g.dr0, g.dc0 = nil, nil
  end
  function g.build()
    local S = {}
    local W1 = cols + 1
    for i = 0, (rowsN + 1) * W1 - 1 do S[i] = 0 end
    for y = 1, rowsN do
      local run = 0
      for x = 1, cols do
        run = run + g.occ[(y - 1) * cols + x]
        S[y * W1 + x] = S[(y - 1) * W1 + x] + run
      end
      if LAY.co then LAY.yield(cols) end
    end
    g.sum, g.W1, g.dr0, g.dc0 = S, W1, nil, nil
  end
  function g.used(x, y, w, h)   -- cases occupées dans [x, x+w) × [y, y+h)
    if not g.sum then g.build() elseif g.dr0 then refresh() end
    local S, W1 = g.sum, g.W1
    return S[(y + h) * W1 + x + w] - S[y * W1 + x + w] - S[(y + h) * W1 + x] + S[y * W1 + x]
  end
  -- (PLACEBUG) le rectangle de cases touche deux bords perpendiculaires = un coin de l'écran : jamais une place
  -- automatique (le symptôme de 4.0.0), sauf la disposition « Coins » qui les veut
  function g.corner(x, y, w, h) return (x <= 0 or x + w >= cols) and (y <= 0 or y + h >= rowsN) end
  function g.freeIn(c0, c1, r0, r1)
    local n, f = 0, 0
    for y = math.max(0, r0), math.min(rowsN - 1, r1) do
      for x = math.max(0, c0), math.min(cols - 1, c1) do n = n + 1; if g.occ[y * cols + x + 1] == 0 then f = f + 1 end end
    end
    return n > 0 and f / n or 0
  end
  for _, r in ipairs(scan.rects) do g.mark(r, 8) end
  return g
end

-- meilleur emplacement libre pour un rectangle w×h (unités UI) près de (tx, ty) ; renvoie l, b, score
local function bestSpot(g, w, h, tx, ty, allowCorner)
  local cw, ch = math.ceil(w / CELL), math.ceil(h / CELL)
  if cw > g.cols or ch > g.rows then return nil end
  -- (LITE) une case sur deux puis affinage autour du meilleur (balayage complet si rien trouvé)
  local best, bx, by
  local function scan(x0, x1, y0, y1, step)
    for y = math.max(0, y0), math.min(g.rows - ch, y1), step do
      for x = math.max(0, x0), math.min(g.cols - cw, x1), step do
        if LAY.co then LAY.yield(3) end
        if g.used(x, y, cw, ch) == 0 and (allowCorner or not (g.corner and g.corner(x, y, cw, ch))) then
          local cx, cy = (x + cw / 2) * CELL, (y + ch / 2) * CELL
          local d = math.sqrt((cx - tx) ^ 2 + (cy - ty) ^ 2)
          if not best or d < best then best, bx, by = d, x, y end
        end
      end
    end
  end
  scan(0, g.cols - cw, 0, g.rows - ch, 2)
  if best then scan(bx - 1, bx + 1, by - 1, by + 1, 1) else scan(0, g.cols - cw, 0, g.rows - ch, 1) end
  if not best then return nil end
  return bx * CELL, by * CELL, best
end

-- point d'ancrage selon le quart d'écran + décalages dans l'échelle du cadre (k)
local function anchorFor(l, b, w, h, W, H, k, forceTop)
  k = k or 1
  local cx, cy = l + w / 2, b + h / 2
  local top = forceTop or cy > H / 2
  local v = top and "TOP" or "BOTTOM"
  local hz
  if math.abs(cx - W / 2) < W * 0.12 then hz = "" elseif cx < W / 2 then hz = "LEFT" else hz = "RIGHT" end
  local x = (hz == "LEFT" and l) or (hz == "RIGHT" and (l + w - W)) or (cx - W / 2)
  local y = top and (b + h - H) or b
  return v .. hz, math.floor(x / k + 0.5), math.floor(y / k + 0.5)
end

local function moduleFrame(modName, frameName)
  local m = TreeAI.modules and TreeAI.modules[modName]
  local f = _G[frameName]
  return m, (type(f) == "table") and f or nil
end

---------------------------------------------------------------------------
-- (PLACEBUG 4.0.1) LA PLACE POSÉE PAR LE JOUEUR EST SACRÉE.
-- 4.0.0 : seul un glisser sur le cadre lui-même marquait la place « à la main » ; la carte (glissée par son en-tête),
-- la barre « Raccourcis » (par sa poignée), le suivi (par ses lignes), la barre du chasseur… restaient « auto » et
-- le placement automatique les reprenait à la connexion suivante ; la position était relue avec GetPoint() après
-- StopMovingOrSizing (le client y met SON ancrage : point / relatif / écran au lieu d'UIParent) puis reposée avec un
-- seul point → ailleurs, voire hors écran (collée au bord / dans un coin par SetClampedToScreen).
-- Maintenant : un crochet sur StartMoving / StopMovingOrSizing de CHAQUE cadre à nous (quelle que soit la poignée)
-- relit le rectangle réel, repose le cadre sur UIParent avec un point explicite (le même des deux côtés, celui du
-- quart d'écran), le note « posé par le joueur » (CharDB().movers + layout.manual) et le module garde sa copie
-- (onMoved). Le cache de mise en page du client (layout-local.txt) n'est plus utilisé pour nos cadres.
---------------------------------------------------------------------------
local movables, moverOrder = {}, {}       -- id -> { frame, id, label, opts } (TreeAI:RegisterMovable, plus bas)

local function moverDB()
  if not (TreeAI.db and TreeAI:CharKey() ~= "?") then
    TreeAI._moverTmp = TreeAI._moverTmp or {}
    return TreeAI._moverTmp
  end
  local c = TreeAI:CharDB()
  c.movers = type(c.movers) == "table" and c.movers or {}
  return c.movers
end

-- rectangle d'un de nos cadres en unités d'UIParent (GetRect × échelle relative) ou nil
local function ourRect(f)
  local l, b, w, h = call(f, "GetRect")
  if not (finite(l) and finite(b) and finite(w) and finite(h)) then return nil end
  local k = (call(f, "GetEffectiveScale") or 1) / (call(_G.UIParent, "GetEffectiveScale") or 1)
  return l * k, b * k, w * k, h * k
end

local playerPlaced, hookManual   -- (définies juste dessous)
do
  local function frameId(f)
    for id, m in pairs(movables) do if m.frame == f then return id end end
    return nil
  end

  --- vrai si le joueur a posé ce cadre lui-même (glisser, mode édition) : aucun placement automatique, aucun
  --- écartement ne le bouge ; seuls « Réinitialiser l'interface », « Placer automatiquement », « Tout remettre auto »,
  --- le clic droit du mode édition ou une disposition le rendent au placement automatique
  function playerPlaced(id)
    if type(id) ~= "string" then return false end
    if layoutState().manual[id] then return true end
    local rec = moverDB()[id]
    if type(rec) == "table" and validAnchor(rec.point, rec.x, rec.y) then return true end
    local m = movables[id]
    if m and m.opts and type(m.opts.isPlaced) == "function" then
      local ok, v = pcall(m.opts.isPlaced)
      if ok and v then return true end
    end
    return false
  end
  TreeAI.IsPlayerPlaced = function(_, id) return playerPlaced(id) end

  --- repose un de nos cadres sur UIParent depuis son rectangle RÉEL (point du quart d'écran, le même des deux côtés,
  --- décalages dans l'échelle du cadre) ; renvoie point, x, y, l, b, w, h (unités d'UIParent) ou nil
  local function anchorFromRect(f, forceTop)
    local W, H = screenSize()
    local l, b, w, h = ourRect(f)
    if not (W and l and w > 0 and h > 0) then return nil end
    local k = tonumber(call(f, "GetScale")) or 1
    local point, x, y = anchorFor(l, b, w, h, W, H, k, forceTop)
    if not setAnchor(f, point, x, y) then return nil end
    if type(f.SetUserPlaced) == "function" then pcall(f.SetUserPlaced, f, false) end
    return point, x, y, l, b, w, h
  end
  function TreeAI:AnchorFromRect(f, forceTop) return anchorFromRect(f, forceTop) end

  --- le joueur vient de lâcher le cadre : ancrage explicite sur UIParent depuis son rectangle réel, place notée
  local function playerMoved(f, role)
    local id = frameId(f) or role
    if type(id) ~= "string" then return nil end
    local point, x, y, l, b, w, h = anchorFromRect(f, id == "panel")
    if not point then return nil end
    local W, H = screenSize()
    local k = tonumber(call(f, "GetScale")) or 1
    local rec = { point = point, x = x, y = y, scale = k, l = l, b = b, zone = TreeAI.ZoneOf(l, b, w, h, W, H) }
    moverDB()[id] = rec
    layoutState().manual[id] = true
    if TreeAI._displaced then TreeAI._displaced[id] = nil end
    local m = movables[id]
    if m and m.opts and m.opts.onMoved then TreeAI.safecall(m.opts.onMoved, point, x, y, k) end
    return rec
  end
  TreeAI._PlayerMoved = playerMoved

  -- crochet posé sur chacun de nos cadres déplaçables (une fois)
  local hooked, movingNow = {}, setmetatable({}, { __mode = "k" })
  function hookManual(f, role)
    if type(f) ~= "table" or hooked[f] then return end
    hooked[f] = role or true
    local hook = _G.hooksecurefunc
    if type(hook) == "function" and type(f.StartMoving) == "function" and type(f.StopMovingOrSizing) == "function" then
      pcall(hook, f, "StartMoving", function(self) movingNow[self] = true end)
      pcall(hook, f, "StopMovingOrSizing", function(self)
        if not movingNow[self] then return end         -- un StopMovingOrSizing sans glisser (fin de redimension…) : rien
        movingNow[self] = nil
        TreeAI.safecall(playerMoved, self, type(hooked[self]) == "string" and hooked[self] or nil)
      end)
    elseif f.HookScript then
      pcall(f.HookScript, f, "OnDragStop", function() if role then layoutState().manual[role] = true end end)
    end
    -- la place est dans NOS sauvegardes : le client ne la garde pas en double (et ne la repose pas à sa façon)
    if type(f.SetDontSavePosition) == "function" then pcall(f.SetDontSavePosition, f, true) end
  end
  TreeAI._HookMoves = hookManual
end

local PANEL_W = { 360, 340, 320, 300 }
local PANEL_L = { 8, 6, 5, 4 }
local LAYOUT_V = 3          -- version du placement : +1 = replacement unique pour les joueurs existants
                            -- (3 = COHERE : colonne « Suivi Forever » de Shortest Path évitée)
TreeAI.LAYOUT_VERSION = LAYOUT_V

-- le rectangle (unités UI) est-il entièrement libre sur la grille ?
local function fitsAt(g, l, b, w, h)
  if l < 0 or b < 0 then return false end
  local c0, r0 = math.floor(l / CELL), math.floor(b / CELL)
  local c1, r1 = math.ceil((l + w) / CELL), math.ceil((b + h) / CELL)
  if c1 > g.cols or r1 > g.rows then return false end
  return g.used(c0, r0, c1 - c0, r1 - r0) == 0
end
TreeAI._FitsAt = fitsAt

-- meilleur emplacement libre selon une fonction de score (plus petit = mieux)
-- (LITE) une case sur deux, puis affinage autour du meilleur : 4× moins de calculs au placement ; rien
-- trouvé ainsi -> balayage complet (un trou étroit n'est jamais raté)
local function bestBy(g, w, h, score, allowCorner)
  local cw, ch = math.ceil(w / CELL), math.ceil(h / CELL)
  if cw > g.cols or ch > g.rows then return nil end
  local best, bx, by
  local function scan(x0, x1, y0, y1, step)
    for y = math.max(0, y0), math.min(g.rows - ch, y1), step do
      for x = math.max(0, x0), math.min(g.cols - cw, x1), step do
        if LAY.co then LAY.yield(3) end
        if g.used(x, y, cw, ch) == 0 and (allowCorner or not (g.corner and g.corner(x, y, cw, ch))) then
          if LAY.co then LAY.yield(10) end
          local d = score(x * CELL, y * CELL)
          if not best or d < best then best, bx, by = d, x, y end
        end
      end
    end
  end
  scan(0, g.cols - cw, 0, g.rows - ch, 2)
  if best then scan(bx - 1, bx + 1, by - 1, by + 1, 1) else scan(0, g.cols - cw, 0, g.rows - ch, 1) end
  if not best then return nil end
  return bx * CELL, by * CELL, best
end


-- UI2 : profils d'écran (16:9 / 21:9 / 4:3), zones réservées au jeu (centre + personnage), dispositions
--- "16:9" | "21:9" | "4:3" selon le rapport largeur / hauteur d'UIParent.
function TreeAI.ScreenProfile(W, H)
  local r = (tonumber(W) or 1920) / math.max(1, tonumber(H) or 1080)
  if r >= 2.0 then return "21:9" elseif r <= 1.45 then return "4:3" end
  return "16:9"
end
--- Retrait des colonnes de HUD : en 21:9 on vise les bords de la bande centrale 16:9 (pas l'extrême bord
--- qu'on ne regarde jamais), ailleurs le bord de l'écran.
function TreeAI.ScreenInset(W, H)
  if TreeAI.ScreenProfile(W, H) ~= "21:9" then return 0 end
  return math.max(0, math.floor((W - H * 16 / 9) / 2 * 0.75))
end
--- Rectangles gardés libres pour le jeu : le centre de l'écran et la zone du personnage (juste dessous).
function TreeAI.ReservedRects(W, H)
  local inset = TreeAI.ScreenInset(W, H)
  local iw = W - 2 * inset
  return {
    { name = "centre", l = inset + iw * 0.34, b = H * 0.38, w = iw * 0.32, h = H * 0.32 },
    { name = "personnage", l = W / 2 - 110, b = H * 0.30, w = 220, h = H * 0.30 },
  }
end
-- dispositions en un clic : tailles + préférence de placement du panneau
TreeAI.DISPOSITIONS = {
  compacte = { label = "Compacte", width = 300, lines = 4, scale = 0.9, radar = 140, alertScale = 0.9,
               widths = { 300 }, lines_ = { 4, 3 } },
  confort  = { label = "Confort", width = 340, lines = 8, scale = 1, radar = 170, alertScale = 1,
               widths = { 360, 340, 320, 300 }, lines_ = { 8, 6, 5, 4 } },
  coins    = { label = "Coins", width = 320, lines = 6, scale = 1, radar = 160, alertScale = 1,
               widths = { 320, 300 }, lines_ = { 6, 5, 4 } },
}
TreeAI.DISPOSITION_ORDER = { "compacte", "confort", "coins" }
local function dispo()
  local s = TreeAI.settings
  local k = s and s.layoutStyle
  return TreeAI.DISPOSITIONS[k or ""] and k or "confort"
end
TreeAI._Dispo = dispo
-- zone (3×3) d'un rectangle : apprise quand le joueur dépose un cadre
function TreeAI.ZoneOf(l, b, w, h, W, H)
  local cx, cy = l + w / 2, b + h / 2
  local v = (cy > H * 2 / 3) and "TOP" or ((cy < H / 3) and "BOTTOM" or "")
  local hz = (cx < W / 3) and "LEFT" or ((cx > W * 2 / 3) and "RIGHT" or "")
  local z = v .. hz
  return z ~= "" and z or "CENTER"
end
local ZONE_CENTER = { TOPLEFT = { 0, 1 }, TOP = { 0.5, 1 }, TOPRIGHT = { 1, 1 }, LEFT = { 0, 0.5 }, CENTER = { 0.5, 0.5 },
  RIGHT = { 1, 0.5 }, BOTTOMLEFT = { 0, 0 }, BOTTOM = { 0.5, 0 }, BOTTOMRIGHT = { 1, 0 } }
TreeAI.ZONE_CENTER = ZONE_CENTER

local function gapBetween(a, l, b, w, h)
  local dx = math.max(a.l - (l + w), l - (a.l + a.w), 0)
  local dy = math.max(a.b - (b + h), b - (a.b + a.h), 0)
  return dx, dy
end

--- Place nos cadres. force = oublie les déplacements manuels (bouton « Placer automatiquement »).
--- strict = passage automatique (connexion, résolution changée) : jamais sur un scan vide (cadres du jeu pas encore
--- mesurables) — renvoie nil, "scan" et le pilote réessaie. Écran pas encore posé : nil, "screen" (refait plus tard).
--- Renvoie la table des placements { role = { point, x, y, l, b, w, h } } (aussi gardée pour /tai placer).
function TreeAI:AutoLayout(force, strict)
  if self:InCombat() then
    -- (UIREDO) placé après le combat = version du placement notée aussi (sinon refait à chaque contrôle)
    self:RunOutOfCombat("autolayout", function() if self:AutoLayout(force) then layoutState().v = LAYOUT_V end end)
    return nil, "combat"
  end
  -- (4.4 SMART) un placement direct (bouton, réglage) remplace un placement découpé encore en cours
  local d = self._layoutDriver
  if d and d.co and coroutine.running() ~= d.co then d.co, d.stable = nil, true end
  local scan = self:ScanScreen()
  if scan.notReady then
    -- (PLACEBUG) UIParent sans taille (connexion) : aucun placement sur des mesures vides, refait dès qu'il en a une
    if self.RequestLayout then self:RequestLayout(force and "force" or "check") end
    return nil, "screen"
  end
  if strict and #scan.rects == 0 then return nil, "scan" end
  local st = layoutState()
  if force then
    -- « Placer automatiquement » : toutes les places posées par le joueur sont oubliées (cadres sans rôle compris)
    st.manual = {}
    local db = moverDB()
    for k in pairs(db) do db[k] = nil end
    for _, id in ipairs(moverOrder) do
      local m = movables[id]
      if m and m.opts and m.opts.onReset then TreeAI.safecall(m.opts.onReset) end
    end
  end
  if self.ResetReflow then self:ResetReflow() end   -- les nouvelles places deviennent « chez lui »
  local W, H = scan.W, scan.H
  local g = newGrid(scan)
  -- le centre de l'écran et le personnage restent au jeu (UI2) ; en 21:9 la bande centrale 16:9
  for _, r in ipairs(TreeAI.ReservedRects(W, H)) do g.mark(r, 0) end
  local S = self.settings or {}
  local D = TreeAI.DISPOSITIONS[dispo()]
  local inset = TreeAI.ScreenInset(W, H)
  local placed = {}
  local named = scan.named
  -- (PLACEBUG) un cadre posé par le joueur (glisser par n'importe quelle poignée, mode édition) ne bouge jamais, et
  -- les cadres automatiques ne se posent pas dessus
  local function keep(role) return not force and playerPlaced(role) end
  if not force and TreeAI._FrameRect then
    for _, id in ipairs(moverOrder) do
      local m = movables[id]
      if m and m.frame and call(m.frame, "IsShown") and playerPlaced(id) then
        local l, b, w, h = TreeAI._FrameRect(m.frame, W, H)
        if l then g.mark({ l = l, b = b, w = w, h = h }, 4) end
      end
    end
  end
  local mm = named.MinimapCluster or named.Minimap or named.MMHolder or named.ElvUI_MinimapHolder
  local party = {}
  for _, n in ipairs(PARTY_NAMES) do if named[n] then party[#party + 1] = named[n] end end

  -- 1. (5.1 INTEG) la bande d'actions (Shortcuts) déjà posée : sa place est réservée (le radar retiré en 5.1 tenait
  --    cette case-là ; sans lui, sur un petit écran, la boussole venait sous la bande)
  local Sc = TreeAI.Shortcuts
  local sr = type(Sc) == "table" and Sc.placed and type(Sc.StripRect) == "function" and Sc.StripRect() or nil
  if sr and sr.w > 0 and sr.h > 0 then g.mark({ l = sr.l - 4, b = sr.b - 4, w = sr.w + 8, h = sr.h + 8 }, 4) end

  -- 2. encadré d'alerte : juste sous la minimap (sinon la place libre la plus proche)
  local al = S.alert
  if al and not keep("alert") then
    local aw, ah = 300 * (al.scale or 1), 40 * (al.scale or 1)
    local tx, ty = W - 140, H - 230
    if mm then tx, ty = mm.l + mm.w / 2, mm.b - ah / 2 - 8 end
    local l, b = bestSpot(g, aw, ah, tx, ty)
    if l then
      local pt, x, y = anchorFor(l, b, aw, ah, W, H, al.scale or 1, true)
      al.pos = { point = pt, x = x, y = y, corner = al.corner }
      placed.alert = { point = pt, x = x, y = y, l = l, b = b, w = aw, h = ah }
      g.mark({ l = l, b = b, w = aw, h = ah }, 4)
      if self.ApplyAlertSettings then self:ApplyAlertSettings() end
    end
  end

  -- 3. boussole : en haut au centre, jamais sur le cadre de la cible
  local C, cf = moduleFrame("Compass", "TreeAICompassFrame")
  hookManual(cf, "compass")
  if C and C.char and not keep("compass") then
    local k = tonumber(C.db and C.db.scale) or 1
    local cw, chh = (tonumber(C.W) or 150) * k, (tonumber(C.H) or 74) * k
    local l, b = bestSpot(g, cw, chh, W / 2, H - 70 - chh / 2)
    if l then
      local pt, x, y = anchorFor(l, b, cw, chh, W, H, k, true)
      C.char.point, C.char.x, C.char.y = pt, x, y
      if cf then setAnchor(cf, pt, x, y) end
      placed.compass = { point = pt, x = x, y = y, l = l, b = b, w = cw, h = chh }
      g.mark({ l = l, b = b, w = cw, h = chh }, 4)
    end
  end

  -- 4. panneau : la plus grande zone libre d'un BORD de l'écran (le centre reste au jeu), loin des cadres
  --    de groupe ; taille adaptée (largeur ≥ 300, lignes sur 2 lignes possibles)
  local P = S.panel
  local c = char()
  local side
  if P and c and not keep("panel") then
    local k = P.scale or 1
    local fsz, gap = look()
    local rowH = (fsz + 4) * 1.4 + gap
    local function heightFor(lines) return (HEADER_H + TAB_ROW_H + 2 + 12 + rowH * lines) * k end
    local style = dispo()
    local function score(l, b, w, h)
      local cx, cy = l + w / 2, b + h / 2
      local sc
      if style == "coins" then                              -- le coin libre le plus proche
        local dx = math.min(math.abs(l - inset), math.abs(W - inset - (l + w)))
        local dy = math.min(b, H - (b + h))
        sc = dx + dy
      elseif style == "compacte" then                       -- groupé avec la minimap / le radar (haut droite)
        local tx = mm and (mm.l + mm.w / 2) or (W - inset - w / 2)
        local ty = mm and (mm.b - h / 2 - 200) or (H * 0.6)
        sc = math.sqrt((cx - tx) ^ 2 + (cy - ty) ^ 2) * 0.6
      else                                                  -- confort : colonne du bord, à hauteur des yeux
        sc = math.min(math.abs(l - inset), math.abs(W - inset - (l + w))) + math.min(cx, W - cx) * 0.15
        sc = sc + math.abs(cy - H * 0.5) * 0.35
      end
      for _, p in ipairs(party) do
        local dx, dy = gapBetween(p, l, b, w, h)
        if dx < 160 and dy < 160 then sc = sc + 700 - dx - dy end
      end
      return sc
    end
    local bestL, bestB, bestScore, bw, bl
    local function search(grid, widths, linesList)
      for wi, pw in ipairs(widths) do
        for li, lines in ipairs(linesList) do
          local w, h = pw * k, heightFor(lines)
          -- (4.4 SMART) borne : un score est ≥ 0, une taille dont la seule pénalité dépasse déjà le meilleur est sautée
          local pen = (wi - 1) * 20 + (li - 1) * 45
          local l, b, d
          if not bestScore or pen < bestScore then
            l, b, d = bestBy(grid, w, h, function(x, y) return score(x, y, w, h) end, style == "coins")
          end
          if l then
            local sc = d + pen     -- garder la taille si possible
            if not bestScore or sc < bestScore then bestL, bestB, bestScore, bw, bl = l, b, sc, pw, lines end
          end
        end
      end
    end
    search(g, D.widths or PANEL_W, D.lines_ or PANEL_L)
    if not bestL then
      -- petit écran : sans la réserve du centre (nos cadres déjà placés restent évités)
      local g2 = newGrid(scan)
      for _, r in pairs(placed) do g2.mark(r, 6) end
      search(g2, PANEL_W, PANEL_L)
    end
    if bestL then
      local w, h = bw * k, heightFor(bl)
      side = (bestL + w / 2 > W / 2) and "RIGHT" or "LEFT"
      local pt, x, y = anchorFor(bestL, bestB, w, h, W, H, k, true)
      if pt == "TOP" then pt, x = (side == "RIGHT") and "TOPRIGHT" or "TOPLEFT",
        math.floor(((side == "RIGHT") and (bestL + w - W) or bestL) / k + 0.5) end
      c.point, c.x, c.y, c.manual = pt, x, y, nil
      P.width, P.maxLines = bw, bl
      placed.panel = { point = pt, x = x, y = y, l = bestL, b = bestB, w = w, h = h, width = bw, lines = bl }
      g.mark({ l = bestL, b = bestB, w = w, h = h }, 6)
      if panel then applyPosition(); self:RefreshPanel() end
    end
  end

  -- 5. cadre de suivi (s'il existe) : sous le suivi des quêtes, sinon côté opposé au panneau
  local TR, tf = moduleFrame("Tracker", "TreeAITrackerFrame")
  hookManual(tf, "tracker")
  if TR and TR.char and not keep("tracker") then
    local k = tonumber(TR.db and TR.db.scale) or 100
    if k > 3 then k = k / 100 end   -- le suivi garde son échelle en %
    local tw = (tonumber(TR.db and TR.db.width) or 300) * k
    local th = 160
    local qt = named.ObjectiveTrackerFrame or named.QuestWatchFrame or named.WatchFrame
      or named.Questie_BaseFrame or named.QuestieTrackerBaseFrame
    local tx, ty
    if qt then tx, ty = qt.l + qt.w / 2, qt.b - th / 2 - 8
    else tx, ty = (side == "RIGHT") and 170 or (W - 170), H * 0.6 end
    local l, b = bestSpot(g, tw, th, tx, ty)
    if l then
      local pt, x, y = anchorFor(l, b, tw, th, W, H, k, true)
      TR.char.point, TR.char.x, TR.char.y = pt, x, y
      if tf then setAnchor(tf, pt, x, y) end
      placed.tracker = { point = pt, x = x, y = y, l = l, b = b, w = tw, h = th }
      g.mark({ l = l, b = b, w = tw, h = th }, 4)
    end
  end

  -- 6. barre du chasseur (tir auto) : au-dessus des barres d'action, au centre (la barre de piège se déplace seule)
  local bars = { { "Hunter", "barPos", 160, 10, "map" } }
  local floorY = 0
  for _, n in ipairs({ "MainMenuBar", "MainActionBar", "MultiBarBottomLeft", "MultiBarBottomRight", "ElvUI_Bar1", "BT4Bar1" }) do
    local r = named[n]
    if r and r.l < W * 0.75 and r.l + r.w > W * 0.25 then floorY = math.max(floorY, r.b + r.h) end
  end
  for _, bd in ipairs(bars) do
    local m = self.modules and self.modules[bd[1]]
    if m and m._active and type(m.db) == "table" and not keep(bd[2]) then
      local l, b = bestSpot(g, bd[3], bd[4] + 6, W / 2, floorY + 110)
      if l then
        local x, y = math.floor(l + bd[3] / 2 - W / 2 + 0.5), math.floor(b + bd[4] / 2 - H / 2 + 0.5)
        if bd[5] == "map" then m.db[bd[2]] = { point = "CENTER", x = x, y = y }
        else m.db[bd[2]] = { "CENTER", x, y } end
        placed[bd[2]] = { point = "CENTER", x = x, y = y, l = l, b = b, w = bd[3], h = bd[4] }
        g.mark({ l = l, b = b, w = bd[3], h = bd[4] + 6 }, 2)
      end
    end
  end

  st.sig = self:LayoutSignature()
  st.last = placed
  self._lastLayout = placed
  self:Fire("LAYOUT_DONE", placed)
  return placed
end

--- "LxH@échelle" de l'écran, ou nil tant qu'UIParent n'a pas sa taille
function TreeAI:LayoutSignature()
  local W, H = screenSize()
  if not W then return nil end
  local sc = call(_G.UIParent, "GetEffectiveScale") or 1
  return ("%dx%d@%.2f"):format(math.floor(W + 0.5), math.floor(H + 0.5), tonumber(sc) or 1)
end

do
  -- (PLACEBUG) « la résolution a vraiment changé » : la taille d'UIParent (unités d'interface) a bougé de plus d'une
  -- case ET de 2 % ; un arrondi d'échelle ne compte pas (nos ancrages suivent les bords d'UIParent)
  local function sigWH(sig) local w, h = tostring(sig or ""):match("^(%d+)x(%d+)") return tonumber(w), tonumber(h) end
  local function screenChanged(old, new)
    local w1, h1 = sigWH(old)
    local w2, h2 = sigWH(new)
    if not (w1 and h1 and w2 and h2) then return old ~= new end
    return math.abs(w1 - w2) > math.max(CELL, w2 * 0.02) or math.abs(h1 - h2) > math.max(CELL, h2 * 0.02)
  end
  TreeAI._ScreenChanged = screenChanged

  --- Premier lancement (rien de placé), nouvelle version du placement ou résolution VRAIMENT changée : un placement
  --- automatique — les cadres posés par le joueur ne bougent jamais. Même écran : rien. Renvoie vrai si placé.
  function TreeAI:CheckAutoLayout(strict)
    local sig = self:LayoutSignature()
    if not sig then
      if self.RequestLayout then self:RequestLayout("check") end
      return false, "screen"
    end
    local st = layoutState()
    local first = st.sig == nil or (tonumber(st.v) or 0) < LAYOUT_V
    if not first and not screenChanged(st.sig, sig) then
      st.sig = sig   -- même écran (arrondi d'échelle…) : rien ne bouge
      return false
    end
    -- nouvelle version du placement : refait UNE fois (les cadres posés par le joueur gardent leur place)
    if (tonumber(st.v) or 0) < LAYOUT_V then
      local P = self.settings and self.settings.panel
      if P and (tonumber(P.width) or 0) < MIN_W then P.width = DEFAULT_W end
    end
    local placed, why = self:AutoLayout(false, strict)
    if placed then st.v = LAYOUT_V end
    return placed and true or false, why
  end
end

--- le placement automatique a-t-il déjà tourné pour ce personnage (une place auto existe) ?
function TreeAI:LayoutPlaced() return layoutState().sig ~= nil end

---------------------------------------------------------------------------
-- (PLACEBUG 4.0.1) UN SEUL passage automatique, quand l'écran est vraiment posé.
-- 4.0.0 (« au lancement tout est bien placé, une seconde après tout se remet dans un coin ») : 1 s après
-- UI_SCALE_CHANGED / DISPLAY_SIZE_CHANGED — que le vrai client envoie pendant la connexion — puis 6 s après READY,
-- CheckAutoLayout comparait une signature d'écran lue en pleine connexion (UIParent pas encore à sa taille, échelle
-- d'interface pas encore appliquée, cadres du jeu pas encore mesurables) ; elle différait → AutoLayout replaçait tout
-- ce qui n'était pas marqué « à la main », sur un scan vide (minimap, suivis, barres inconnus) : encadré / radar dans
-- le coin en haut à droite, carte collée au bord gauche… et encore une fois à +6 s ; le placement vivant écartait
-- en plus les cadres posés par le joueur.
-- Maintenant : on attend une taille d'UIParent valide et IDENTIQUE pendant 1,5 s, 3 s de calme après l'entrée dans
-- le monde (le mode édition de Blizzard a reposé ses cadres) et hors combat, puis UN contrôle : même écran = rien ne
-- bouge ; premier lancement / résolution vraiment changée = un placement des seuls cadres automatiques.
---------------------------------------------------------------------------
do
  local SETTLE, STABLE, POLL, PATIENCE = 3, 1.5, 0.5, 6
  local drv = { pending = nil, key = nil, since = 0, notBefore = 0, quietUntil = 0, polling = false, stable = false,
    firstTry = nil }
  TreeAI._layoutDriver = drv
  local function nowT()
    local ok, t = pcall(_G.GetTime or error)
    return (ok and tonumber(t)) or 0
  end
  local function sizeKey()
    local W, H = screenSize()
    if not W then return nil end
    return math.floor(W + 0.5) .. "x" .. math.floor(H + 0.5)
  end
  local poll
  local function schedule()
    if drv.polling then return end
    drv.polling = true
    -- minuterie du cœur (jamais attribuée au module qui a demandé, donc jamais sautée s'il est coupé)
    local run = TreeAI._RunAs or function(_, fn) fn() end
    run(nil, function() TreeAI:After(POLL, poll) end)
  end
  poll = function()
    drv.polling = false
    if not drv.pending and not drv.co then return end
    local t = nowT()
    local key = sizeKey()
    if key ~= drv.key then drv.key, drv.since = key, t end
    if drv.pending and not drv.co and key and t - drv.since >= STABLE and t >= drv.notBefore and not TreeAI:InCombat() then
      local kind = drv.pending
      drv.pending = nil
      -- cadres créés depuis (boussole, suivi…) : inscrits = leurs glisser sont notés comme les autres
      if TreeAI._RegisterCoreMovables then TreeAI.safecall(TreeAI._RegisterCoreMovables) end
      -- scan vide = cadres du jeu pas encore mesurables : on patiente (6 s au plus, puis on place quand même)
      drv.firstTry = drv.firstTry or t
      local strict = t - drv.firstTry < PATIENCE
      -- (4.4 SMART) le calcul part dans une coroutine, repris image après image jusqu'au bout (voir LAY.yield)
      local co = coroutine.create(function()
        if kind == "force" then return TreeAI:AutoLayout(true, false) end
        return TreeAI:CheckAutoLayout(strict)
      end)
      drv.co, drv.coKind, drv.coAt = co, kind, nil
    end
    if drv.co and TreeAI:InCombat() then   -- combat entre deux tranches : reprise après (rien ne bouge en combat)
      drv.polling = true
      local run = TreeAI._RunAs or function(_, fn) fn() end
      run(nil, function() TreeAI:After(POLL, poll) end)
      return
    end
    if drv.co then
      local co = drv.co
      -- image « longue » (≥ 0,5 s depuis la tranche précédente : chargement, tests à gros pas) : tout d'un coup, comme avant
      local coarse = t - (drv.coAt or t) >= 0.5
      drv.coAt = t
      local ok, _, why
      repeat
        LAY.co, LAY.n = co, 0
        ok, _, why = coroutine.resume(co)
        LAY.co = nil
      until not (ok and coarse and coroutine.status(co) ~= "dead")
      if ok and coroutine.status(co) ~= "dead" then
        drv.polling = true
        local run = TreeAI._RunAs or function(_, fn) fn() end
        run(nil, function() TreeAI:After(0, poll) end)
        return
      end
      drv.co = nil
      if not ok then TreeAI:Debug("placement:", tostring(_)) why = nil end
      local kind = drv.coKind
      if why == "scan" or why == "screen" or why == "combat" then
        drv.pending = drv.pending or kind
      else
        drv.firstTry, drv.stable = nil, true
        if TreeAI._SanitizePlacements then TreeAI.safecall(TreeAI._SanitizePlacements, TreeAI) end
      end
    end
    if drv.pending then schedule() end
  end
  --- demande un contrôle du placement : fusionné (un seul passage), fait quand l'écran est posé et stable, hors combat
  function TreeAI:RequestLayout(kind)
    if kind == "force" or not drv.pending then drv.pending = kind or "check" end
    drv.stable = false
    schedule()
  end
  --- l'écran est posé, stable et contrôlé (le placement vivant peut alors écarter les cadres automatiques)
  function TreeAI:ScreenStable()
    return (drv.stable and not drv.pending and nowT() >= drv.quietUntil) and true or false
  end
  local owner = {}
  local function changed()
    drv.key = nil                 -- la taille doit de nouveau rester la même 1,5 s avant tout contrôle
    TreeAI:RequestLayout("check")
  end
  for _, ev in ipairs({ "UI_SCALE_CHANGED", "DISPLAY_SIZE_CHANGED" }) do TreeAI:RegisterEvent(ev, owner, changed) end
  -- écran de chargement (connexion, /reload, instance, pierre de foyer) : les cadres du jeu se reposent → calme
  TreeAI:RegisterEvent("PLAYER_ENTERING_WORLD", owner, function()
    local t = nowT()
    drv.notBefore = math.max(drv.notBefore, t + SETTLE)
    drv.quietUntil = math.max(drv.quietUntil, t + SETTLE + STABLE)
  end)
  TreeAI:On("READY", owner, function()
    local t = nowT()
    drv.notBefore = math.max(drv.notBefore, t + SETTLE)
    drv.quietUntil = math.max(drv.quietUntil, t + SETTLE + STABLE)
    TreeAI:RequestLayout("check")
  end)
end

TreeAI:RegisterSlash("placer", function(rest)
  rest = tostring(rest or ""):lower()
  local placed = TreeAI:AutoLayout(rest ~= "doux")
  if not placed then TreeAI:Print(L["Placement après le combat."]); return end
  local n = 0
  for _ in pairs(placed) do n = n + 1 end
  TreeAI:Print(L["Cadres TreeAI placés dans les zones libres"] .. " (" .. n .. ").  " .. L["/tai placer doux : garde ceux que tu as déplacés"])
end, "placer automatiquement les cadres TreeAI dans les zones libres de l'écran")

---------------------------------------------------------------------------
-- Cadres déplaçables + mode édition (/tai edit, bouton du panneau).
-- TreeAI:RegisterMovable(frame, id, label, opts) : chaque module y inscrit ses cadres.
--   opts = { onMoved = function(point, x, y, scale) end,  -- le module enregistre sa position (sinon TreeAI)
--            onReset = function() end,                    -- retour à la place par défaut / auto
--            minScale = 0.5, maxScale = 2, show = function() end, hide = function() end }
-- Positions manuelles gardées PAR PERSONNAGE (CharDB().movers) ; elles passent avant le placement auto.
---------------------------------------------------------------------------
local editing, editBar = false, nil
local SNAP, EDGE, NEAR = 10, 12, 8

-- (PLACEBUG) un ancrage valide ou rien (jamais ClearAllPoints sans SetPoint réussi)
local function placeFrame(f, point, x, y, scale) return setAnchor(f, point, x, y, scale) end

function TreeAI:RegisterMovable(frame, id, label, opts)
  if type(frame) ~= "table" or type(id) ~= "string" then return false end
  opts = opts or {}
  local m = movables[id]
  if not m then moverOrder[#moverOrder + 1] = id; m = {}; movables[id] = m end
  m.frame, m.id, m.label, m.opts = frame, id, label or id, opts
  if frame.SetMovable then pcall(frame.SetMovable, frame, true) end
  if frame.SetClampedToScreen then pcall(frame.SetClampedToScreen, frame, true) end   -- jamais hors écran
  local saved = moverDB()[id]
  if type(saved) == "table" and not validAnchor(saved.point, saved.x, saved.y) then
    moverDB()[id] = nil   -- (PLACEBUG) donnée incomplète (x / y absents…) : jamais « nil → 0 → coin de l'écran »
    saved = nil
  end
  if type(saved) == "table" and not opts.onMoved then placeFrame(frame, saved.point, saved.x, saved.y, saved.scale) end
  hookManual(frame, id)
  if editing and self._BuildOverlay then self._BuildOverlay(m) end
  return true
end
function TreeAI:GetMovables() return movables, moverOrder end

-- aimantation : grille de 10, bords de l'écran, bords des autres cadres TreeAI
function TreeAI.SnapRect(l, b, w, h, W, H, others)
  l, b = math.floor(l / SNAP + 0.5) * SNAP, math.floor(b / SNAP + 0.5) * SNAP
  if l < EDGE then l = 0 elseif W - (l + w) < EDGE then l = W - w end
  if b < EDGE then b = 0 elseif H - (b + h) < EDGE then b = H - h end
  for _, o in ipairs(others or {}) do
    if math.abs(l - o.l) < NEAR then l = o.l elseif math.abs(l - (o.l + o.w)) < NEAR then l = o.l + o.w
    elseif math.abs((l + w) - o.l) < NEAR then l = o.l - w end
    if math.abs(b - o.b) < NEAR then b = o.b elseif math.abs(b - (o.b + o.h)) < NEAR then b = o.b + o.h
    elseif math.abs((b + h) - o.b) < NEAR then b = o.b - h end
  end
  return l, b
end

--- Position manuelle (après glisser / molette) : aimant, ancrage, sauvegarde ; passe avant le placement auto.
function TreeAI:CommitMove(id, l, b, scale)
  local m = movables[id]
  if not (m and m.frame) then return nil end
  local f = m.frame
  local W, H = screenSize()
  if not W then return nil end
  local _, _, w, h = ourRect(f)
  if not w then
    local k0 = scale or call(f, "GetScale") or 1
    w, h = (call(f, "GetWidth") or 100) * k0, (call(f, "GetHeight") or 20) * k0
  end
  w, h = w or 100, h or 20
  local others = {}
  for _, oid in ipairs(moverOrder) do
    local o = movables[oid]
    if oid ~= id and o.frame and call(o.frame, "IsShown") then
      local ol, ob, ow, oh = ourRect(o.frame)
      if ol then others[#others + 1] = { l = ol, b = ob, w = ow, h = oh } end
    end
  end
  l, b = TreeAI.SnapRect(l, b, w, h, W, H, others)
  -- déposé SUR un cadre de Blizzard / d'un addon (plus d'un quart caché) : glisse vers la place libre la plus
  -- proche (≤ 300 px) ; sinon la place du joueur est gardée telle quelle
  local S = self.settings
  if S and S.snapFree ~= false and TreeAI._LightRects then
    local area = 0
    local ownName = call(f, "GetName")
    for _, r in ipairs(TreeAI._LightRects(W, H)) do
      if r.name == ownName then r = { l = 0, b = 0, w = 0, h = 0 } end   -- (REPLACE) jamais son propre rectangle
      local ox = math.min(r.l + r.w, l + w) - math.max(r.l, l)
      local oy = math.min(r.b + r.h, b + h) - math.max(r.b, b)
      if ox > 0 and oy > 0 then area = area + ox * oy end
    end
    if area > 0.25 * w * h then
      local g = newGrid(self:ScanScreen())
      for _, o in ipairs(others) do g.mark(o, 2) end
      local nl, nb = bestSpot(g, w, h, l + w / 2, b + h / 2, true)   -- le joueur décide : coin permis
      if nl and math.abs(nl - l) + math.abs(nb - b) <= 300 then l, b = nl, nb end
    end
  end
  local k = scale or call(f, "GetScale") or 1
  local point, x, y = anchorFor(l, b, w, h, W, H, k, id == "panel")
  placeFrame(f, point, x, y, scale)
  local rec = { point = point, x = x, y = y, scale = k, l = l, b = b, zone = TreeAI.ZoneOf(l, b, w, h, W, H) }
  moverDB()[id] = rec
  layoutState().manual[id] = true
  if self._AcceptOverlaps then self:_AcceptOverlaps(id, l, b, w, h) end
  if m.opts.onMoved then TreeAI.safecall(m.opts.onMoved, point, x, y, k) end
  return rec
end

--- Remet un cadre à sa place automatique (ou par défaut) ; id nil = tous.
function TreeAI:ResetMovable(id)
  local db, st = moverDB(), layoutState()
  local list = id and { id } or moverOrder
  for _, i in ipairs(list) do
    db[i] = nil
    st.manual[i] = nil
    local m = movables[i]
    if m and m.opts.onReset then TreeAI.safecall(m.opts.onReset) end
  end
  if not self:InCombat() then self:AutoLayout(false) end
  if self._RefreshOverlays then self._RefreshOverlays() end
end

function TreeAI:SetFramesLocked(v)
  local S = self.settings
  if S and S.panel then S.panel.locked = v and true or false end
  local C, TR = self.modules.Compass, self.modules.Tracker
  if C and C.db then C.db.locked = v and true or false end
  if TR and TR.db then TR.db.lock = v and true or false end
  if self._RefreshOverlays then self._RefreshOverlays() end
  self:RequestRefresh()
end
function TreeAI:FramesLocked()
  local S = self.settings
  return (S and S.panel and S.panel.locked) and true or false
end

local overlays = {}
--- (UIREDO) retire un cadre des déplaçables (ex. barre amarrée dans la barre « Raccourcis » : elle bouge avec elle)
function TreeAI:UnregisterMovable(id)
  if not movables[id] then return false end
  movables[id] = nil
  for i = #moverOrder, 1, -1 do if moverOrder[i] == id then table.remove(moverOrder, i) end end
  local o = overlays[id]
  if o then o:Hide() end
  return true
end
local function refreshOverlay(o)
  local m = o.mover
  local locked = TreeAI:FramesLocked()
  o:ClearAllPoints()
  if m.frame then o:SetAllPoints(m.frame) end
  if o.SetBackdropColor then
    if locked then o:SetBackdropColor(0.4, 0.4, 0.4, 0.35) else o:SetBackdropColor(0.1, 0.6, 1, 0.35) end
  end
  local sc = call(m.frame, "GetScale") or 1
  o.text:SetText(("%s%s  |cffaaaaaa×%.2f|r"):format(L[m.label], locked and (" (" .. L["verrouillé"] .. ")") or "", sc))
end

local function buildOverlay(m)
  local o = overlays[m.id]
  if not o then
    local template = _G.BackdropTemplateMixin and "BackdropTemplate" or nil
    o = _G.CreateFrame("Button", nil, _G.UIParent, template)
    o._taiOurs = true          -- (PLACEBUG) notre calque : jamais un obstacle pour le placement
    o:SetFrameStrata("DIALOG")
    o:SetMovable(true)
    o:EnableMouse(true)
    if o.EnableMouseWheel then o:EnableMouseWheel(true) end
    o:RegisterForDrag("LeftButton")
    o:RegisterForClicks("RightButtonUp")
    if o.SetBackdrop then
      o:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
      o:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
    end
    o.text = o:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    o.text:SetPoint("CENTER", o, "CENTER", 0, 0)
    o:SetScript("OnDragStart", function(self)
      if TreeAI:FramesLocked() or TreeAI:InCombat() then return end
      local l, b, w, h = ourRect(self)
      self:ClearAllPoints()
      if l then self:SetPoint("BOTTOMLEFT", _G.UIParent, "BOTTOMLEFT", l, b); self:SetSize(w, h) end
      self:StartMoving()
    end)
    o:SetScript("OnDragStop", function(self)
      self:StopMovingOrSizing()
      local l, b = ourRect(self)
      if l then TreeAI:CommitMove(self.mover.id, l, b) end
      refreshOverlay(self)
    end)
    o:SetScript("OnMouseWheel", function(self, delta)
      if TreeAI:FramesLocked() or TreeAI:InCombat() then return end
      local mv = self.mover
      local sc = call(mv.frame, "GetScale") or 1
      sc = math.max(mv.opts.minScale or 0.5, math.min(mv.opts.maxScale or 2, sc + (delta > 0 and 0.05 or -0.05)))
      sc = math.floor(sc * 100 + 0.5) / 100
      local l, b = ourRect(mv.frame)
      call(mv.frame, "SetScale", sc)
      if l then TreeAI:CommitMove(mv.id, l, b, sc) end
      refreshOverlay(self)
    end)
    o:SetScript("OnClick", function(self, button)
      if button == "RightButton" then TreeAI:ResetMovable(self.mover.id) end
    end)
    o:SetScript("OnEnter", function(self)
      showTooltip(self, L[self.mover.label], {
        { L["Glisser : déplacer (aimanté)"], 0.8, 0.8, 0.8 }, { L["Molette : taille"], 0.8, 0.8, 0.8 },
        { L["Clic droit : remettre à sa place auto"], 0.8, 0.8, 0.8 } })
    end)
    o:SetScript("OnLeave", hideTooltip)
    overlays[m.id] = o
  end
  o.mover = m
  refreshOverlay(o)
  o:Show()
  return o
end
TreeAI._BuildOverlay = buildOverlay
TreeAI._RefreshOverlays = function()
  if not editing then return end
  for _, o in pairs(overlays) do if o:IsShown() then refreshOverlay(o) end end
  if editBar and editBar.refresh then editBar.refresh() end
end
function TreeAI:GetOverlays() return overlays end

local function barButton(parent, text, x, fn)
  local ok, b = pcall(_G.CreateFrame, "Button", nil, parent, "UIPanelButtonTemplate")
  if not ok or not b then
    -- (3.9.2) template missing: plain button with its own text, so « Fini » always exists
    ok, b = pcall(_G.CreateFrame, "Button", nil, parent)
    if not ok or not b then return nil end
    local fs = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    fs:SetAllPoints()
    b.SetText = function(self, v) fs:SetText(v) end
    if b.SetNormalFontObject then pcall(b.SetNormalFontObject, b, "GameFontNormalSmall") end
  end
  b:SetSize(118, 20)
  b:SetPoint("LEFT", parent, "LEFT", x, 0)
  b:SetText(text)
  b:SetScript("OnClick", function() TreeAI.safecall(fn) end)
  return b
end

local function buildEditBar()
  if editBar then return editBar end
  local template = _G.BackdropTemplateMixin and "BackdropTemplate" or nil
  editBar = _G.CreateFrame("Frame", "TreeAIEditBar", _G.UIParent, template)
  editBar:SetClampedToScreen(true)
  editBar:SetSize(112 + 122 * 4, 30)
  -- (3.9.2) below the top-centre compass and ABOVE every overlay: the compass overlay used to cover « Fini »
  editBar:SetPoint("TOP", _G.UIParent, "TOP", 0, -150)
  editBar:SetFrameStrata("FULLSCREEN_DIALOG")
  if editBar.SetFrameLevel then editBar:SetFrameLevel(200) end
  if editBar.SetToplevel then editBar:SetToplevel(true) end
  editBar:SetMovable(true); editBar:EnableMouse(true)
  editBar:RegisterForDrag("LeftButton")
  editBar:SetScript("OnDragStart", function(f) f:StartMoving() end)
  editBar:SetScript("OnDragStop", function(f) f:StopMovingOrSizing() end)
  -- Échap closes the edit mode (our frame only) ; hiding the bar for any reason ends the mode
  editBar:SetScript("OnHide", function() if editing then TreeAI:SetEditMode(false) end end)
  if type(_G.UISpecialFrames) == "table" then table.insert(_G.UISpecialFrames, "TreeAIEditBar") end
  if editBar.SetBackdrop then
    editBar:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
      edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 10,
      insets = { left = 2, right = 2, top = 2, bottom = 2 } })
    editBar:SetBackdropColor(0.05, 0.08, 0.06, 0.95)
  end
  local t = editBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  t:SetPoint("LEFT", editBar, "LEFT", 8, 0)
  t:SetText("|cffffd133" .. L["Mode édition"] .. "|r TreeAI")
  editBar.lock = barButton(editBar, "", 112, function() TreeAI:SetFramesLocked(not TreeAI:FramesLocked()) end)
  editBar.auto = barButton(editBar, L["Tout remettre auto"], 112 + 122, function() TreeAI:ResetMovable(nil) end)
  -- (4.0 QA) « Comment ? » : une infobulle (survol ou clic), jamais une ligne dans le chat
  local function helpTip(b)
    showTooltip(b, L["Comment ?"], {
      { L["Glisse un cadre (aimant : grille 10 px, bords, autres cadres), molette = taille, clic droit = place auto."], 0.85, 0.85, 0.85 } })
  end
  editBar.help = barButton(editBar, L["Comment ?"], 112 + 244, function() if editBar.help then helpTip(editBar.help) end end)
  if editBar.help then
    editBar.help:SetScript("OnEnter", helpTip)
    editBar.help:SetScript("OnLeave", hideTooltip)
  end
  editBar.done = barButton(editBar, L["Fini"], 112 + 366, function() TreeAI:SetEditMode(false) end)
  -- Échap = « Fini » (UISpecialFrames cache la barre -> on quitte le mode édition)
  if TreeAI.Theme and TreeAI.Theme.Window then
    TreeAI.Theme:Window(editBar, { id = "editbar", header = false })
  end
  editBar:SetScript("OnHide", function() if editing then TreeAI:SetEditMode(false) end end)
  function editBar.refresh()
    if editBar.lock then editBar.lock:SetText(TreeAI:FramesLocked() and L["Déverrouiller tout"] or L["Verrouiller tout"]) end
  end
  return editBar
end

--- Mode édition : calque coloré + nom sur chaque cadre TreeAI ; glisser, molette, clic droit.
function TreeAI:SetEditMode(on)
  if on and self:InCombat() then self:CombatRefused(); return false end
  editing = on and true or false
  if editing then
    if self._RegisterCoreMovables then self._RegisterCoreMovables() end
    if not panel then self:CreatePanel() end
    -- (4.0 QA) la carte « Prochaine étape » est l'affichage : le panneau texte seulement s'il est déjà ouvert
    if panel and not panel:IsShown() and not (self.CardIsHUD and self.CardIsHUD()) then self:ShowPanel() end
    if self.ShowAlert then self:ShowAlert({ text = L["Encadré d'alerte (exemple)"], prio = 3 }, true) end
    if alert then alert.hold = true end
    for _, id in ipairs(moverOrder) do
      local m = movables[id]
      if m.opts.show then self.safecall(m.opts.show) end
      if m.frame and call(m.frame, "IsShown") then buildOverlay(m) end
    end
    buildEditBar()
    editBar.refresh()
    editBar:Show()
  else
    for _, o in pairs(overlays) do o:Hide() end
    if editBar then editBar:Hide() end
    if alert then alert.hold = false; alert:Hide() end
    for _, id in ipairs(moverOrder) do
      local m = movables[id]
      if m.opts.hide then self.safecall(m.opts.hide) end
    end
  end
  self:Fire("EDIT_MODE", editing)
  return true
end
function TreeAI:IsEditMode() return editing end

TreeAI:RegisterSlash("edit", function() TreeAI:SetEditMode(not editing) end,
  "mode édition : déplacer / agrandir les cadres TreeAI (aimantés), verrouiller, remettre en place")
TreeAI:RegisterSlash("editer", function() TreeAI:SetEditMode(not editing) end)

-- cadres de base : panneau, encadré d'alerte ; boussole et suivi dès qu'ils existent
local function registerCore()
  if panel and not movables.panel then
    TreeAI:RegisterMovable(panel, "panel", "Panneau texte (ancien)", {
      onMoved = function(point, x, y, sc)
        local c, s = char(), acc()
        if c then c.point, c.x, c.y, c.manual = point, x, y, true end
        if s and sc then s.scale = sc end
      end,
      -- (PLACEBUG) glissé à la main (même avant 4.0.1) = posé par le joueur ; remis = place automatique
      isPlaced = function() local c = char() return c and c.manual and true or false end,
      onReset = function() local c = char() if c then c.manual = nil end end,
    })
  end
  if not movables.alert and (alert or makeAlert()) then
    TreeAI:RegisterMovable(alert, "alert", "Encadré d'alerte", {
      onMoved = function(point, x, y, sc)
        local s = alertSettings()
        if s then s.pos = { point = point, x = x, y = y, corner = s.corner }; if sc then s.scale = sc end end
      end,
      onReset = function() local s = alertSettings(); if s then s.pos = nil end end,
    })
  end
  local C, cf = moduleFrame("Compass", "TreeAICompassFrame")
  if C and cf and not movables.compass then
    TreeAI:RegisterMovable(cf, "compass", "Boussole", {
      onMoved = function(point, x, y, sc)
        if C.char then C.char.point, C.char.x, C.char.y = point, x, y end
        if C.db and sc then C.db.scale = sc end
      end,
    })
  end
  local TR, tf = moduleFrame("Tracker", "TreeAITrackerFrame")
  if TR and tf and not movables.tracker then
    TreeAI:RegisterMovable(tf, "tracker", "Suivi des quêtes", {
      onMoved = function(point, x, y, sc)
        if TR.char then TR.char.point, TR.char.x, TR.char.y = point, x, y end
        if TR.db and sc then TR.db.scale = math.floor(sc * 100 + 0.5) end
      end,
    })
  end
end
TreeAI._RegisterCoreMovables = registerCore
do
  local owner = {}
  TreeAI:On("READY", owner, function() TreeAI:After(1, registerCore) end)
end

--- « Réinitialiser l'interface » : tous les cadres TreeAI reviennent à leur place automatique, tailles,
--- onglets et transparence par défaut, panneau affiché sur « Maintenant ». Hors combat.
function TreeAI:ResetInterface()
  if self:InCombat() then
    self:RunOutOfCombat("resetui", function() self:ResetInterface() end)
    self:CombatRefused(L["Réinitialisation après le combat."])
    return false
  end
  local db = moverDB()
  for k in pairs(db) do db[k] = nil end
  if self.ResetReflow then self:ResetReflow() end
  for k in pairs(self._accepted or {}) do self._accepted[k] = nil end
  local st = layoutState()
  st.manual = {}
  local s, c = acc(), char()
  if s then
    s.scale, s.alpha, s.width, s.maxLines, s.locked, s.shown = 1, 0.9, DEFAULT_W, 8, false, true
    s.fontSize, s.lineGap, s.iconSize = 11, ROW_GAP, 13
  end
  if c then c.tab, c.mini, c.manual = "now", false, nil end
  local al = alertSettings()
  if al then al.pos, al.scale, al.corner = nil, 1, "TOPRIGHT" end
  moreOpen = false
  for _, id in ipairs(moverOrder) do
    local m = movables[id]
    if m and m.opts.onReset then self.safecall(m.opts.onReset) end
    if m and m.frame then call(m.frame, "SetScale", 1) end
  end
  local mods = self.modules or {}
  if mods.Compass and mods.Compass.db then mods.Compass.db.scale = 1 end
  if mods.Radar and mods.Radar.db then mods.Radar.db.size, mods.Radar.db.compact = 170, false end
  if editing then self:SetEditMode(false) end
  -- (4.0 QA) la carte « Prochaine étape » reste l'affichage (à la place automatique du panneau) ; le panneau texte
  -- seulement sans carte. Le retour des cadres à leur place est la réponse au clic : rien dans le chat.
  local Wn = self.Window
  if not (Wn and Wn.ShowHUD and Wn.ShowHUD(true)) then self:ShowPanel() end
  self:AutoLayout(true)
  st.v = LAYOUT_V
  return true
end

TreeAI:RegisterSlash("reinit", function() TreeAI:ResetInterface() end,
  "réinitialiser l'interface TreeAI (places, tailles, onglets par défaut)")

---------------------------------------------------------------------------
-- UI2 : placement vivant. Quand un cadre de Blizzard / d'un addon apparaît, grandit ou bouge (le suivi de
-- Questie s'allonge, un cadre de groupe arrive…) et tombe sur un cadre TreeAI, celui-ci glisse vers la place
-- libre la plus proche ; il revient chez lui dès que la place se libère. Les chevauchements acceptés par le
-- joueur (il a déposé le cadre là) restent acceptés tant que l'obstacle ne change pas. Lecture seule des
-- cadres des autres, hors combat, 1 passage léger / 2 s (cadres connus seulement, pas d'EnumerateFrames).
---------------------------------------------------------------------------
do
  local displaced = {}       -- id -> { point, rp, x, y, l, b } : la vraie place (« chez lui »)
  local accepted = {}        -- id -> { [nom] = signature } : chevauchements voulus par le joueur
  local lastSig
  TreeAI._displaced, TreeAI._accepted = displaced, accepted

  -- 1er point d'ancrage (5 valeurs : `call` n'en rend que 4)
  local function pointOf(f)
    if type(f) ~= "table" or type(f.GetPoint) ~= "function" then return nil end
    local ok, pt, rel, rp, x, y = pcall(f.GetPoint, f, 1)
    if ok then return pt, rel, rp, x, y end
  end
  -- rectangle d'un cadre à nous (GetRect, sinon depuis son point d'ancrage sur UIParent)
  -- rectangle VOULU par l'ancrage (point d'UIParent + décalages × échelle), sans le rabattement à l'écran
  local function anchorRect(f, W, H)
    if not W then return nil end
    local k = tonumber(call(f, "GetScale")) or 1
    local w, h = (tonumber(call(f, "GetWidth")) or 0) * k, (tonumber(call(f, "GetHeight")) or 0) * k
    if not (finite(w) and finite(h)) or w <= 0 or h <= 0 then return nil end
    if (tonumber(call(f, "GetNumPoints")) or 1) > 1 then return nil end
    local pt, rel, rp, x, y = pointOf(f)
    if type(pt) ~= "string" or not POINTS[pt] or (rel and rel ~= _G.UIParent) then return nil end
    rp = POINTS[rp] and rp or pt
    x, y = (tonumber(x) or 0) * k, (tonumber(y) or 0) * k
    local ax = (rp:find("LEFT") and 0) or (rp:find("RIGHT") and W) or W / 2
    local ay = (rp:find("TOP") and H) or (rp:find("BOTTOM") and 0) or H / 2
    local ox = (pt:find("LEFT") and 0) or (pt:find("RIGHT") and w) or w / 2
    local oy = (pt:find("TOP") and h) or (pt:find("BOTTOM") and 0) or h / 2
    return ax + x - ox, ay + y - oy, w, h
  end
  TreeAI._AnchorRect = anchorRect
  local function frameRect(f, W, H)
    local l, b, w, h = ourRect(f)
    if l and w and w > 0 then return l, b, w, h end
    return anchorRect(f, W, H)
  end
  TreeAI._FrameRect = frameRect

  --- (PLACEBUG) une place sauvegardée qui met le cadre HORS de l'écran (plus de la moitié dehors : ancrage relu de
  --- travers par 4.0.0, donnée d'un autre client…) n'est pas une place : le cadre revient à sa place automatique /
  --- par défaut. Les places sur l'écran ne sont jamais touchées. Renvoie le nombre de cadres remis.
  function TreeAI:_SanitizePlacements()
    local W, H = screenSize()
    if not W or self:InCombat() then return 0 end
    local n = 0
    local db = moverDB()
    for id, rec in pairs(db) do   -- place du mode édition incomplète (x / y absents) : jamais lue « 0, 0 »
      if type(rec) ~= "table" or not validAnchor(rec.point, rec.x, rec.y) then db[id] = nil end
    end
    for _, id in ipairs(moverOrder) do
      local m = movables[id]
      local f = m and m.frame
      local l, b, w, h
      if f then l, b, w, h = anchorRect(f, W, H) end
      if l then
        local ox = math.max(0, math.min(l + w, W) - math.max(l, 0))
        local oy = math.max(0, math.min(b + h, H) - math.max(b, 0))
        if ox * oy < 0.5 * w * h then
          moverDB()[id] = nil
          layoutState().manual[id] = nil
          if m.opts and m.opts.onReset then TreeAI.safecall(m.opts.onReset) end
          n = n + 1
        end
      end
    end
    if n > 0 then self:AutoLayout(false) end
    return n
  end

  local function rsig(r) return ("%d,%d,%d,%d"):format(math.floor(r.l / 16), math.floor(r.b / 16), math.floor(r.w / 16), math.floor(r.h / 16)) end
  local function overlap(a, l, b, w, h)
    local ox = math.min(a.l + a.w, l + w) - math.max(a.l, l)
    local oy = math.min(a.b + a.h, b + h) - math.max(a.b, b)
    if ox <= 4 or oy <= 4 then return 0 end
    return ox * oy
  end

  -- passage léger : cadres connus par leur nom (suivis, groupe, compteurs, minimap, barres…)
  local function lightRects(W, H)
    local out = {}
    local seen = {}
    local function one(n)
      local f = _G[n]
      if type(f) == "table" and not seen[f] then
        seen[f] = true
        local r = guideRect(f, W, H, n)
        if r then r.name = r.name or n; out[#out + 1] = r end
      end
    end
    for _, n in ipairs(SCAN_NAMES) do one(n) end
    for n in pairs(TreeAI._discovered) do one(n) end   -- (COHERE) suivis d'addons vus par préfixe
    return out
  end
  TreeAI._LightRects = lightRects

  -- (5.0 INTEG) OBSTACLES GÉNÉRIQUES : tout cadre visible posé sur UIParent par le jeu ou par un AUTRE addon, nommé ou
  -- non (compteurs de dégâts, cadres d'unité d'un addon, barres d'action, flèche d'un guide…). Sert à choisir une place
  -- (bande d'actions, alerte) : lu SEULEMENT quand on place quelque chose, jamais dans un OnUpdate, et gardé 20 s
  -- (plusieurs placements de suite = une lecture). Lecture bon marché : les enfants directs d'UIParent (quelques
  -- centaines), pas tous les cadres du client. Les fenêtres que le joueur ouvre et ferme (panneaux du jeu, sacs,
  -- boîtes de dialogue, infobulles) n'en font pas partie : on ne fuit pas une fenêtre de passage.
  ;(function()   -- (dans une fonction : le fichier a déjà ses 200 variables locales)
  local OB = { at = -100, list = nil, sig = nil }
  OB.STRATA = { DIALOG = true, HIGH = true, FULLSCREEN = true, FULLSCREEN_DIALOG = true, TOOLTIP = true, BACKGROUND = true }
  OB.NAME = {}
  for w in ("ContainerFrame StaticPopup DropDownList GameMenu LootFrame GroupLootFrame MerchantFrame BankFrame MailFrame TradeFrame GossipFrame QuestFrame CharacterFrame SpellBookFrame WorldMapFrame FriendsFrame AuctionFrame AuctionHouseFrame ClassTrainerFrame TradeSkillFrame CraftFrame ItemRefTooltip GameTooltip ShoppingTooltip HelpFrame InterfaceOptions SettingsPanel VideoOptions AddonList TalentFrame PlayerTalentFrame InspectFrame TaxiFrame LFG PVP Baganator Bagnon AdiBags BattlefieldFrame ReadyCheck RolePoll ColorPicker OpenMail ItemText PetStable TabardFrame GuildRegistrar Petition Calendar Collections EncounterJournal Communities MacroFrame KeyBinding ChatConfig TimeManagerFrame Stopwatch"):gmatch("%S+") do OB.NAME[#OB.NAME + 1] = w end
  function OB.transient(f, name)
    if OB.STRATA[call(f, "GetFrameStrata") or ""] then return true end
    if type(name) == "string" then
      for _, pre in ipairs(OB.NAME) do if name:sub(1, #pre) == pre then return true end end
      local pw, sf = _G.UIPanelWindows, _G.UISpecialFrames
      if type(pw) == "table" and pw[name] ~= nil then return true end
      if type(sf) == "table" then for i = 1, #sf do if sf[i] == name then return true end end end
    end
    return false
  end
  --- { { l, b, w, h, name }, … } en unités d'UIParent ; maxAge = durée de vie acceptée (20 s par défaut, 0 = relire)
  function TreeAI:ScreenObstacles(maxAge)
    local W, H = screenSize()
    if not W then return {} end
    local t = (type(_G.GetTime) == "function" and _G.GetTime()) or 0
    local sig = math.floor(W) .. "x" .. math.floor(H)
    if OB.list and OB.sig == sig and t - OB.at <= (tonumber(maxAge) or 20) then return OB.list end
    local out, seen = {}, {}
    for _, r in ipairs(lightRects(W, H)) do out[#out + 1] = r if r.name and _G[r.name] then seen[_G[r.name]] = true end end
    local P = _G.UIParent
    local kids = (type(P) == "table" and type(P.GetChildren) == "function") and { pcall(P.GetChildren, P) } or { false }
    if kids[1] then
      local maxArea = W * H * 0.30
      for i = 2, #kids do
        local f = kids[i]
        if type(f) == "table" and not seen[f] and call(f, "IsVisible") then
          seen[f] = true
          local r = rectOf(f, W, H)
          if r and r.w * r.h <= maxArea and not OB.transient(f, r.name) then out[#out + 1] = r end
        end
      end
    end
    OB.list, OB.at, OB.sig = out, t, sig
    TreeAI._obstScans = (TreeAI._obstScans or 0) + 1
    return out
  end
  function TreeAI:ObstaclesChanged() OB.list = nil end
  --- la place l, b, w, h (unités d'UIParent) est-elle libre de tout obstacle ? → vrai, ou faux + le nom du 1er obstacle
  function TreeAI:SpotIsFree(l, b, w, h, margin)
    margin = margin or 0
    for _, r in ipairs(self:ScreenObstacles()) do
      if l < r.l + r.w + margin and r.l < l + w + margin and b < r.b + r.h + margin and r.b < b + h + margin then
        return false, r.name or "cadre sans nom"
      end
    end
    return true
  end
  end)()
  --- (5.0 INTEG) un autre addon affiche déjà en permanence une colonne « trajet + composants de métier » (Shortest Path
  --- Forever : « Suivi Forever ») → { name, route = true, reagents = true } ; sinon nil. TreeAI n'en affiche pas une 2e.
  function TreeAI:OtherColumn()
    local spf = rawget(_G, "ShortestPathForever")
    local Q = self.modules and self.modules.Quests
    local o = Q and type(Q.others) == "function" and Q.others() or nil
    if type(spf) ~= "table" and not (type(o) == "table" and o.route) then return nil end
    -- (5.1 LOOK) chaque lien se coupe dans « Autres addons » : coupé = TreeAI remontre sa propre liste
    local A = self.Addons
    if type(A) == "table" and A._active and type(A.Wanted) == "function" then
      local route = A.Wanted("spf", "arrow")
      local reagents = not (type(A.Has) == "function" and A.Has("skillup")) or A.Wanted("skillup", "prof")
      if not (route or reagents) then return nil end
      return { name = "Suivi Forever", route = route, reagents = reagents }
    end
    return { name = "Suivi Forever", route = true, reagents = true }
  end

  --- Obstacles (nouveaux ou changés) sur le cadre `id` placé en l, b, w, h.
  local function blockers(id, rects, l, b, w, h)
    local hits, area = {}, 0
    local acc = accepted[id] or {}
    for _, r in ipairs(rects) do
      local a = overlap(r, l, b, w, h)
      if a > 0 and acc[r.name or "?"] ~= rsig(r) then hits[#hits + 1] = r; area = area + a end
    end
    return hits, area
  end

  --- Le joueur dépose un cadre : ce qu'il recouvre déjà est accepté (sa décision), la zone est apprise.
  function TreeAI:_AcceptOverlaps(id, l, b, w, h)
    local W, H = screenSize()
    if not W then return end
    local acc = {}
    for _, r in ipairs(lightRects(W, H)) do
      if overlap(r, l, b, w, h) > 0 then acc[r.name or "?"] = rsig(r) end
    end
    accepted[id] = acc
    displaced[id] = nil
  end

  local function shownMovers(skip, W, H)
    local out = {}
    for _, oid in ipairs(moverOrder) do
      local o = movables[oid]
      if oid ~= skip and o and o.frame and call(o.frame, "IsShown") then
        local l, b, w, h = frameRect(o.frame, W, H)
        if l then out[#out + 1] = { id = oid, l = l, b = b, w = w, h = h } end
      end
    end
    return out
  end

  --- Un passage : renvoie { id = { l, b } | { home = true } } des cadres déplacés (nil = rien à faire).
  function TreeAI:Reflow(force)
    local S = self.settings
    if not S or S.reflow == false or editing then return nil end
    if self:InCombat() then return nil end
    local W, H = screenSize()
    if not W then return nil end
    local rects = lightRects(W, H)
    local parts = {}
    for _, r in ipairs(rects) do parts[#parts + 1] = tostring(r.name) .. "=" .. rsig(r) end
    for _, o in ipairs(shownMovers(nil, W, H)) do parts[#parts + 1] = "@" .. o.id .. "=" .. rsig(o) end
    table.sort(parts)
    local sig = table.concat(parts, ";")
    if sig == lastSig and not force then return nil end
    lastSig = sig
    local moved, grid = {}, nil
    for _, id in ipairs(moverOrder) do
      local m = movables[id]
      local f = m and m.frame
      -- (PLACEBUG) seulement les cadres placés automatiquement : un cadre posé par le joueur reste où il l'a mis
      if id ~= "alert" and f and call(f, "IsShown") and not (m.opts and m.opts.noReflow) and not playerPlaced(id) then
        local l, b, w, h = frameRect(f, W, H)
        if l then
          local home = displaced[id]
          local hl, hb = l, b
          if home then hl, hb = home.l, home.b end
          local rs = rects
          if id == "compass" then
            -- (5.1 INTEG) la bande d'actions posée automatiquement garde sa place en haut à gauche (petit écran : il n'y
            -- en a pas d'autre) ; c'est la boussole qui s'écarte — avant, le carré du radar retiré lui gardait cette case
            local Sc = TreeAI.Shortcuts
            local sr = type(Sc) == "table" and Sc.placed == "auto" and type(Sc.StripRect) == "function" and Sc.StripRect() or nil
            if sr then
              rs = {}
              for i = 1, #rects do rs[i] = rects[i] end
              rs[#rs + 1] = { l = sr.l, b = sr.b, w = sr.w, h = sr.h, name = "TreeAIStrip" }
            end
          end
          local hits = blockers(id, rs, hl, hb, w, h)
          if #hits > 0 then
            if not grid then
              grid = newGrid(self:ScanScreen())
              for _, r in ipairs(TreeAI.ReservedRects(W, H)) do grid.mark(r, 0) end
            end
            -- nos autres cadres visibles comptent aussi (on ne glisse pas sur un voisin)
            local g = grid
            for _, o in ipairs(shownMovers(id, W, H)) do g.mark(o, 4) end
            local nl, nb = bestSpot(g, w, h, hl + w / 2, hb + h / 2)
            if not nl and id == "compass" then
              -- (5.1 INTEG) petit écran (800×600) : sans la réserve du centre, comme le panneau (nos cadres restent évités)
              local g2 = newGrid(self:ScanScreen())
              for _, o in ipairs(shownMovers(id, W, H)) do g2.mark(o, 4) end
              nl, nb = bestSpot(g2, w, h, hl + w / 2, hb + h / 2)
            end
            local hp, _, hrp, hx, hy = pointOf(f)
            -- (PLACEBUG) jamais écarté sans une vraie place où revenir (pas de « CENTER 0,0 » inventé)
            if nl and (math.abs(nl - l) > 2 or math.abs(nb - b) > 2) and (home or validAnchor(hp, hx, hy)) then
              if not home then
                displaced[id] = { point = hp, rp = POINTS[hrp] and hrp or hp, x = hx, y = hy, l = l, b = b }
              end
              local k = call(f, "GetScale") or 1
              local pt, x, y = anchorFor(nl, nb, w, h, W, H, k, id == "panel")
              if placeFrame(f, pt, x, y) then moved[id] = { l = nl, b = nb, w = w, h = h } end
            end
            grid = nil   -- les marques de ce cadre ne doivent pas gêner le suivant
          elseif home then
            if validAnchor(home.point, home.x, home.y) and POINTS[home.rp] then
              if home.rp == home.point then setAnchor(f, home.point, home.x, home.y)
              else call(f, "ClearAllPoints"); call(f, "SetPoint", home.point, _G.UIParent, home.rp, home.x, home.y) end
            end
            displaced[id] = nil
            moved[id] = { home = true, l = home.l, b = home.b, w = w, h = h }
          end
        end
      end
    end
    if not next(moved) then return nil end
    self:Fire("LAYOUT_REFLOW", moved)
    return moved
  end
  function TreeAI:IsDisplaced(id) return displaced[id] ~= nil end
  function TreeAI:ResetReflow() for k in pairs(displaced) do displaced[k] = nil end; lastSig = nil end

  local owner = {}
  TreeAI:On("READY", owner, function()
    -- (LITE) 5 s : la place des cadres change rarement ; (UIREDO) écran stable 3 passages de suite → un passage
    -- sur deux (10 s), retour à 5 s dès que quelque chose bouge
    -- (4.4 SMART) recul progressif : écran stable → 5, 10, 20 puis 40 s entre deux relevés (≈ 150 cadres lus à chaque
    -- fois) ; le moindre changement ramène à 5 s
    local quiet, n = 0, 0
    TreeAI:NewTicker(5, function()
      local S = TreeAI.settings
      if not (S and S.reflow ~= false) or TreeAI:InCombat() then return end
      -- (PLACEBUG) jamais pendant la connexion / un écran de chargement : l'écran doit être posé et contrôlé
      if TreeAI.ScreenStable and not TreeAI:ScreenStable() then return end
      local every = quiet >= 9 and 8 or quiet >= 6 and 4 or quiet >= 3 and 2 or 1
      n = n + 1
      if n < every then return end
      n = 0
      local before = lastSig
      TreeAI.safecall(TreeAI.Reflow, TreeAI)
      if lastSig == before then quiet = quiet + 1 else quiet = 0 end
    end)
  end)
end

--- Disposition en un clic : "compacte" | "confort" | "coins". Tailles + placement auto refait (hors combat).
function TreeAI:ApplyDisposition(name)
  local D = self.DISPOSITIONS[name or ""]
  if not D then return false end
  if self:InCombat() then
    self:RunOutOfCombat("dispo", function() self:ApplyDisposition(name) end)
    self:Print(L["Disposition après le combat."])
    return false
  end
  local S = self.settings
  if not S then return false end
  S.layoutStyle = name
  local P = S.panel
  if P then P.width, P.maxLines, P.scale = D.width, D.lines, D.scale end
  if S.alert then S.alert.scale = D.alertScale end
  local db = moverDB()
  for k in pairs(db) do db[k] = nil end
  if self.ResetReflow then self:ResetReflow() end
  for k in pairs(self._accepted or {}) do self._accepted[k] = nil end
  for _, id in ipairs(moverOrder) do
    local m = movables[id]
    if m and m.opts.onReset then self.safecall(m.opts.onReset) end
  end
  if panel then applyPosition() end
  local placed = self:AutoLayout(true)
  if panel then self:RefreshPanel() end
  self:Fire("DISPOSITION", name)
  return placed and true or false, placed
end
function TreeAI:GetDisposition() return self._Dispo() end

TreeAI:RegisterSlash("disposition", function(rest)
  rest = tostring(rest or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  local map = { compact = "compacte", compacte = "compacte", confort = "confort", coins = "coins", coin = "coins" }
  local n = map[rest]
  if not n then
    TreeAI:Print(L["Disposition"] .. " : " .. L[TreeAI.DISPOSITIONS[TreeAI:GetDisposition()].label]
      .. "  (/tai disposition compacte|confort|coins)")
    return
  end
  TreeAI:ApplyDisposition(n)
  TreeAI:Print(L["Disposition"] .. " : " .. L[TreeAI.DISPOSITIONS[n].label])
end, "disposition des cadres en un clic : compacte, confort ou coins")
